"""
文档元数据存储管理器
提供文档生命周期管理功能
"""

import json
import os
import logging
from datetime import datetime
from typing import List, Dict, Optional, Any
from dataclasses import dataclass, asdict, field

logger = logging.getLogger(__name__)


@dataclass
class DocumentRecord:
    """文档元数据记录"""
    doc_id: str                    # 内容哈希作为唯一ID
    filename: str                  # 原始文件名
    content_hash: str              # 内容MD5哈希
    file_path: str                 # 存储路径
    file_size: int                 # 文件大小(字节)
    doc_type: str                  # 文档类型
    upload_time: str               # 上传时间
    chunk_count: int               # 分块数量
    status: str = "active"         # active/deleted
    searchable: bool = True        # 是否参与检索
    version: int = 1               # 版本号
    tags: List[str] = field(default_factory=list)  # 标签
    regulation_group_id: str = ""  # 同一制度分组ID
    regulation_group_name: str = ""  # 同一制度分组名称
    version_label: str = ""  # 版本标签（如：2018版）
    storage_file_id: str = ""  # 统一文件存储ID
    knowledge_labels: Dict[str, List[str]] = field(default_factory=dict)  # 通用知识分类标签
    
    def to_dict(self) -> Dict:
        return asdict(self)
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'DocumentRecord':
        allowed_fields = set(cls.__dataclass_fields__.keys())
        normalized = {k: v for k, v in (data or {}).items() if k in allowed_fields}
        raw_labels = normalized.get("knowledge_labels")
        if isinstance(raw_labels, dict):
            cleaned: Dict[str, List[str]] = {}
            for key, value in raw_labels.items():
                normalized_key = str(key or "").strip()
                if not normalized_key:
                    continue
                if isinstance(value, list):
                    items = [str(v).strip() for v in value if str(v).strip()]
                elif value is None:
                    items = []
                else:
                    item = str(value).strip()
                    items = [item] if item else []
                cleaned[normalized_key] = items
            normalized["knowledge_labels"] = cleaned
        elif raw_labels is not None:
            normalized["knowledge_labels"] = {}
        return cls(**normalized)


class DocumentMetadataStore:
    """文档元数据管理器"""
    
    def __init__(self, storage_path: str = "./data/document_metadata.json"):
        self.storage_path = storage_path
        self.documents: Dict[str, DocumentRecord] = {}
        self._last_loaded_mtime_ns: Optional[int] = None
        self._last_loaded_size: Optional[int] = None
        self._ensure_dir()
        self._load()
    
    def _ensure_dir(self):
        """确保存储目录存在"""
        dir_path = os.path.dirname(self.storage_path)
        if dir_path and not os.path.exists(dir_path):
            os.makedirs(dir_path, exist_ok=True)
    
    def _load(self):
        """从文件加载元数据"""
        if not os.path.exists(self.storage_path):
            self.documents = {}
            self._last_loaded_mtime_ns = None
            self._last_loaded_size = None
            return

        try:
            stat = os.stat(self.storage_path)
            with open(self.storage_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            loaded_documents: Dict[str, DocumentRecord] = {}
            for doc_id, record in data.items():
                loaded_documents[doc_id] = DocumentRecord.from_dict(record)
            self.documents = loaded_documents
            self._last_loaded_mtime_ns = int(getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1_000_000_000)))
            self._last_loaded_size = int(stat.st_size)
            logger.info(f"已加载 {len(self.documents)} 条文档元数据")
        except Exception as e:
            logger.error(f"加载元数据失败: {e}")
            self.documents = {}
            self._last_loaded_mtime_ns = None
            self._last_loaded_size = None

    def refresh_if_changed(self) -> bool:
        """
        当元数据文件发生变化时，从磁盘轻量重载。
        :return: True 表示执行了重载
        """
        if not os.path.exists(self.storage_path):
            if self.documents:
                self.documents = {}
                self._last_loaded_mtime_ns = None
                self._last_loaded_size = None
                logger.info("元数据文件已删除，清空内存缓存: %s", self.storage_path)
                return True
            return False

        try:
            stat = os.stat(self.storage_path)
        except OSError as e:
            logger.warning("读取元数据文件状态失败: %s", e)
            return False

        current_mtime_ns = int(getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1_000_000_000)))
        current_size = int(stat.st_size)
        if (
            self._last_loaded_mtime_ns == current_mtime_ns
            and self._last_loaded_size == current_size
        ):
            return False

        self._load()
        return True
    
    def save(self):
        """保存元数据到文件"""
        try:
            data = {k: v.to_dict() for k, v in self.documents.items()}
            with open(self.storage_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            try:
                stat = os.stat(self.storage_path)
                self._last_loaded_mtime_ns = int(getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1_000_000_000)))
                self._last_loaded_size = int(stat.st_size)
            except OSError:
                self._last_loaded_mtime_ns = None
                self._last_loaded_size = None
        except Exception as e:
            logger.error(f"保存元数据失败: {e}")
    
    def add_document(self, record: DocumentRecord, save: bool = True) -> bool:
        """
        添加文档记录
        :param save: 是否立即落盘
        :return: True表示新增，False表示更新
        """
        if record.doc_id in self.documents:
            # 已存在，更新版本
            existing = self.documents[record.doc_id]
            existing.version += 1
            existing.upload_time = record.upload_time
            existing.chunk_count = record.chunk_count
            existing.status = "active"
            existing.searchable = bool(record.searchable)
            existing.file_path = record.file_path
            existing.filename = record.filename
            existing.knowledge_labels = dict(record.knowledge_labels or {})
            if record.storage_file_id:
                existing.storage_file_id = record.storage_file_id
            if save:
                self.save()
            logger.info(f"更新文档记录: {record.filename}, 版本: {existing.version}")
            return False  # 更新
        
        self.documents[record.doc_id] = record
        if save:
            self.save()
        logger.info(f"新增文档记录: {record.filename}")
        return True  # 新增
    
    def get_document(self, doc_id: str) -> Optional[DocumentRecord]:
        """获取单个文档"""
        return self.documents.get(doc_id)
    
    def get_document_by_filename(self, filename: str) -> Optional[DocumentRecord]:
        """通过文件名查找文档"""
        for doc in self.documents.values():
            if doc.filename == filename and doc.status == "active":
                return doc
        return None
    
    def list_documents(
        self, 
        doc_type: str = None,
        status: str = "active",
        keyword: str = None
    ) -> List[DocumentRecord]:
        """列出文档（支持过滤）"""
        results = []
        for doc in self.documents.values():
            if status and doc.status != status:
                continue
            if doc_type and doc.doc_type != doc_type:
                continue
            if keyword and keyword.lower() not in doc.filename.lower():
                continue
            results.append(doc)
        return sorted(results, key=lambda x: x.upload_time, reverse=True)
    
    def delete_document(self, doc_id: str, soft_delete: bool = True) -> bool:
        """
        删除文档
        :param soft_delete: True表示软删除，False表示硬删除
        """
        if doc_id not in self.documents:
            return False
        
        if soft_delete:
            self.documents[doc_id].status = "deleted"
            logger.info(f"软删除文档: {doc_id}")
        else:
            del self.documents[doc_id]
            logger.info(f"硬删除文档: {doc_id}")
        
        self.save()
        return True
    
    def restore_document(self, doc_id: str) -> bool:
        """恢复已删除的文档"""
        if doc_id in self.documents and self.documents[doc_id].status == "deleted":
            self.documents[doc_id].status = "active"
            self.save()
            logger.info(f"恢复文档: {doc_id}")
            return True
        return False
    
    def document_exists(self, doc_id: str, include_deleted: bool = False) -> bool:
        """检查文档是否存在"""
        if doc_id not in self.documents:
            return False
        if not include_deleted and self.documents[doc_id].status == "deleted":
            return False
        return True
    
    def get_stats(self) -> Dict:
        """获取统计信息"""
        total = len(self.documents)
        active = sum(1 for d in self.documents.values() if d.status == "active")
        deleted = sum(1 for d in self.documents.values() if d.status == "deleted")
        total_chunks = sum(
            d.chunk_count for d in self.documents.values() 
            if d.status == "active"
        )
        total_size = sum(
            d.file_size for d in self.documents.values()
            if d.status == "active"
        )
        
        # 按类型统计
        type_stats = {}
        for d in self.documents.values():
            if d.status == "active":
                doc_type = d.doc_type
                if doc_type not in type_stats:
                    type_stats[doc_type] = {"count": 0, "chunks": 0}
                type_stats[doc_type]["count"] += 1
                type_stats[doc_type]["chunks"] += d.chunk_count
        
        return {
            "total_documents": total,
            "active_documents": active,
            "deleted_documents": deleted,
            "total_chunks": total_chunks,
            "total_size_bytes": total_size,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
            "by_type": type_stats
        }
    
    def get_all_doc_ids(self, status: str = "active") -> List[str]:
        """获取所有文档ID列表"""
        return [
            doc_id for doc_id, doc in self.documents.items()
            if doc.status == status or status is None
        ]

    def clear_all(self, delete_storage_file: bool = True) -> Dict[str, int]:
        """
        清空所有文档元数据
        :param delete_storage_file: 是否删除元数据存储文件
        :return: 清理统计
        """
        removed_total = len(self.documents)
        removed_active = sum(1 for d in self.documents.values() if d.status == "active")
        removed_deleted = sum(1 for d in self.documents.values() if d.status == "deleted")

        self.documents = {}

        if delete_storage_file:
            try:
                if os.path.exists(self.storage_path):
                    os.remove(self.storage_path)
            except Exception as e:
                logger.error(f"删除元数据文件失败: {e}")
                # 文件删除失败时至少保证内存和文件内容一致
                self.save()
        else:
            self.save()

        logger.info(f"已清空元数据: total={removed_total}, active={removed_active}, deleted={removed_deleted}")
        return {
            "removed_total": removed_total,
            "removed_active": removed_active,
            "removed_deleted": removed_deleted
        }
