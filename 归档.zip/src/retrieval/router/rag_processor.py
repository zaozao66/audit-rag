import hashlib
import json
import logging
import os
import re
import shutil
from difflib import SequenceMatcher
from collections import defaultdict, deque
from datetime import datetime
from typing import Any, Dict, List, Optional, Set, Tuple

import src.indexing.graph.ontology as ontology
from src.indexing.graph.graph_builder import GraphBuilder
from src.indexing.graph.graph_retriever import GraphRetriever
from src.indexing.graph.graph_store import GraphStore
from src.indexing.graph.labels import (
    doc_type_label,
    entity_type_key,
    entity_type_label,
    relation_key,
    relation_label,
)
from src.indexing.metadata.document_metadata_store import DocumentMetadataStore, DocumentRecord
from src.indexing.vector.embedding_providers import EmbeddingProvider
from src.indexing.vector.vector_store import VectorStore
from src.ingestion.splitters.audit_issue_chunker import AuditIssueChunker
from src.ingestion.splitters.audit_report_chunker import AuditReportChunker
from src.ingestion.splitters.document_chunker import DocumentChunker
from src.ingestion.splitters.law_document_chunker import LawDocumentChunker
from src.ingestion.splitters.technical_standard_chunker import TechnicalStandardChunker
from src.ingestion.splitters.smart_chunker import SmartChunker
from src.llm.providers.llm_provider import LLMProvider
from src.retrieval.rerank.rerank_provider import RerankProvider
from src.retrieval.router.intent_router import IntentRouter
from src.retrieval.searchers.vector_retriever import VectorRetriever

logger = logging.getLogger(__name__)

PAGE_PATTERN = re.compile(r"\[\[?PAGE:(\d+)\]?\]")
RECTIFICATION_STATUS_LABELS = {
    "completed": "已整改",
    "in_progress": "整改中",
    "pending": "待整改",
}
EVIDENCE_NODE_TYPES = {ontology.ENTITY_CHUNK, ontology.ENTITY_DOCUMENT}
EMBEDDING_INPUT_MAX_CHARS = 8192
EMBEDDING_SAFE_CHUNK_MAX_CHARS = 6000
REGULATION_DOC_TYPES = {"internal_regulation", "external_regulation"}
ACCOUNTING_STANDARD_ROOT_PATTERN = re.compile(
    r"^(企业会计准则第\s*[一二三四五六七八九十百千万零〇两\d]+\s*号[^\n]{0,120}|企业会计准则应用指南[^\n]{0,120})$"
)


class RAGProcessor:
    """RAG processor orchestrating ingestion, retrieval, graph, and generation."""

    def __init__(
        self,
        embedding_provider: EmbeddingProvider,
        chunk_size: int = 512,
        overlap: int = 50,
        vector_store_path: str = "./vector_store_text_embedding",
        chunker_type: str = "default",
        rerank_provider: RerankProvider = None,
        llm_provider: LLMProvider = None,
        scope: str = "default",
        intent_router_enabled: bool = True,
        intent_router_default_intent: str = "comprehensive_query",
        intent_router_fixed_top_k: Optional[int] = None,
        intent_router_fixed_doc_types: Optional[List[str]] = None,
        intent_router_default_retrieval_plan: Optional[Dict[str, Any]] = None,
    ):
        self.embedding_provider = embedding_provider
        self.scope = str(scope or "default")
        self.chunker_type = chunker_type
        self.vector_store_path = vector_store_path
        self.rerank_provider = rerank_provider
        self.llm_provider = llm_provider

        self._init_chunker(chunker_type, chunk_size, overlap)
        self.vector_store: Optional[VectorStore] = None
        self.dimension: Optional[int] = None

        self.router = IntentRouter(
            llm_provider=llm_provider,
            enabled=intent_router_enabled,
            default_intent=intent_router_default_intent,
            fixed_top_k=intent_router_fixed_top_k,
            fixed_doc_types=intent_router_fixed_doc_types,
            default_retrieval_plan=intent_router_default_retrieval_plan,
        )
        self.retriever: Optional[VectorRetriever] = None

        self.graph_store = GraphStore()
        self.graph_retriever: Optional[GraphRetriever] = None

        metadata_path = vector_store_path.replace("vector_store", "document_metadata") + ".json"
        self.metadata_store = DocumentMetadataStore(storage_path=metadata_path)

        logger.info(
            "RAG处理器初始化完成，scope=%s，重排序功能%s，LLM功能%s，意图识别%s",
            self.scope,
            "启用" if rerank_provider else "禁用",
            "启用" if llm_provider else "禁用",
            "启用" if intent_router_enabled else "禁用",
        )

    def _init_chunker(self, chunker_type, chunk_size, overlap):
        if chunker_type == "regulation":
            self.chunker = LawDocumentChunker(chunk_size=chunk_size, overlap=overlap)
        elif chunker_type == "technical_standard":
            self.chunker = TechnicalStandardChunker(chunk_size=chunk_size, overlap=overlap)
        elif chunker_type == "audit_report":
            self.chunker = AuditReportChunker(chunk_size=chunk_size, overlap=overlap)
        elif chunker_type == "audit_issue":
            self.chunker = AuditIssueChunker(chunk_size=chunk_size, overlap=overlap)
        elif chunker_type == "smart":
            self.chunker = SmartChunker(chunk_size=chunk_size, overlap=overlap)
        else:
            self.chunker = DocumentChunker(chunk_size=chunk_size, overlap=overlap)
        logger.info("使用【%s】分块器", chunker_type)

    def _graph_store_path(self, base_path: str = None) -> str:
        base = os.path.abspath(base_path or self.vector_store_path)
        return f"{base}.graph.json"

    def _full_text_store_dir(self, base_path: str = None) -> str:
        base = os.path.abspath(base_path or self.vector_store_path)
        return f"{base}.fulltext"

    def _preview_store_dir(self, base_path: str = None) -> str:
        base = os.path.abspath(base_path or self.vector_store_path)
        return f"{base}.preview"

    def _full_text_path(self, doc_id: str, base_path: str = None) -> str:
        return os.path.join(self._full_text_store_dir(base_path), f"{doc_id}.txt")

    def _preview_chunks_path(self, doc_id: str, base_path: str = None) -> str:
        return os.path.join(self._preview_store_dir(base_path), f"{doc_id}.chunks.json")

    def _original_store_dir(self, base_path: str = None) -> str:
        base = os.path.abspath(base_path or self.vector_store_path)
        return f"{base}.originals"

    def _safe_suffix_from_paths(self, filename: str, source_path: str) -> str:
        filename_ext = os.path.splitext(str(filename or ""))[1]
        source_ext = os.path.splitext(str(source_path or ""))[1]
        suffix = filename_ext or source_ext or ".bin"
        if not suffix.startswith("."):
            suffix = f".{suffix}"
        return suffix.lower()

    def _original_file_path(self, doc_id: str, filename: str = "", source_path: str = "", base_path: str = None) -> str:
        suffix = self._safe_suffix_from_paths(filename, source_path)
        return os.path.join(self._original_store_dir(base_path), f"{doc_id}{suffix}")

    def _persist_original_file(
        self,
        doc_id: str,
        source_path: str,
        filename: str = "",
        base_path: str = None,
    ) -> Optional[str]:
        source = str(source_path or "").strip()
        if not source or not os.path.exists(source):
            return None

        target = self._original_file_path(doc_id, filename=filename, source_path=source, base_path=base_path)
        os.makedirs(os.path.dirname(target), exist_ok=True)
        try:
            shutil.copy2(source, target)
            return target
        except Exception as e:
            logger.warning("持久化原始文件失败: doc_id=%s source=%s err=%s", doc_id, source, e)
            return None

    def _save_full_text(self, doc_id: str, text: str, base_path: str = None) -> None:
        path = self._full_text_path(doc_id, base_path)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(text or "")

    def _format_preview_chunks(self, doc_id: str, chunks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        formatted: List[Dict[str, Any]] = []
        for idx, chunk in enumerate(chunks or []):
            metadata = chunk.get("metadata", {}) or {}
            text = str(chunk.get("text", "") or "")
            chunk_index = chunk.get("chunk_index")
            if chunk_index is None:
                chunk_index = idx
            try:
                chunk_index = int(chunk_index)
            except (TypeError, ValueError):
                chunk_index = idx

            global_index = chunk.get("global_index")
            if global_index is None:
                global_index = chunk_index
            try:
                global_index = int(global_index)
            except (TypeError, ValueError):
                global_index = chunk_index

            page_nos = metadata.get("page_nos")
            if page_nos is None:
                page_nos = chunk.get("page_nos", [])

            section_path = metadata.get("section_path")
            if section_path is None:
                section_path = chunk.get("section_path", [])

            knowledge_labels = metadata.get("knowledge_labels")
            if knowledge_labels is None:
                knowledge_labels = chunk.get("knowledge_labels", {})
            knowledge_labels = self._normalize_knowledge_labels(knowledge_labels)

            formatted.append(
                {
                    "chunk_index": chunk_index,
                    "chunk_id": str(chunk.get("chunk_id", "") or f"{doc_id}_chunk_{idx}"),
                    "text": text,
                    "text_preview": chunk.get("text_preview") or (text[:200] + "..." if len(text) > 200 else text),
                    "char_count": int(chunk.get("char_count", len(text)) or len(text)),
                    "global_index": global_index,
                    "metadata": {
                        "filename": metadata.get("filename", chunk.get("filename", "")),
                        "doc_type": metadata.get("doc_type", chunk.get("doc_type", "")),
                        "page_nos": page_nos or [],
                        "header": metadata.get("header", chunk.get("header", "")),
                        "section_path": section_path or [],
                        "semantic_boundary": metadata.get("semantic_boundary", chunk.get("semantic_boundary", "")),
                        "knowledge_labels": knowledge_labels,
                    },
                }
            )
        return formatted

    def _save_preview_chunks(self, doc_id: str, chunks: List[Dict[str, Any]], base_path: str = None) -> None:
        path = self._preview_chunks_path(doc_id, base_path)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self._format_preview_chunks(doc_id, chunks), f, ensure_ascii=False, indent=2)

    def _load_full_text(self, doc_id: str, base_path: str = None) -> Optional[str]:
        path = self._full_text_path(doc_id, base_path)
        if not os.path.exists(path):
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                return f.read()
        except Exception as e:
            logger.warning("读取原文缓存失败: doc_id=%s err=%s", doc_id, e)
            return None

    def _load_preview_chunks(self, doc_id: str, base_path: str = None) -> Optional[List[Dict[str, Any]]]:
        path = self._preview_chunks_path(doc_id, base_path)
        if not os.path.exists(path):
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, list):
                return []
            normalized = self._format_preview_chunks(doc_id, data)
            if normalized != data:
                self._save_preview_chunks(doc_id, normalized, base_path=base_path)
            return normalized
        except Exception as e:
            logger.warning("读取预览分块失败: doc_id=%s err=%s", doc_id, e)
            return None

    def _delete_full_text(self, doc_id: str, base_path: str = None) -> bool:
        path = self._full_text_path(doc_id, base_path)
        if not os.path.exists(path):
            return False
        os.remove(path)
        return True

    def _delete_preview_chunks(self, doc_id: str, base_path: str = None) -> bool:
        path = self._preview_chunks_path(doc_id, base_path)
        if not os.path.exists(path):
            return False
        os.remove(path)
        return True

    def _ensure_vector_store(self):
        if not self.vector_store:
            try:
                self.load_vector_store(self.vector_store_path)
            except Exception as e:
                error_msg = f"向量库不存在，请先处理文档。错误: {str(e)}"
                logger.error(error_msg)
                raise ValueError(error_msg)

        if not self.retriever:
            self.retriever = VectorRetriever(self.vector_store, self.embedding_provider)

    def _ensure_graph_index(self):
        if self.graph_retriever:
            return

        graph_path = self._graph_store_path()
        try:
            if self.graph_store.exists(graph_path):
                self.graph_store.load(graph_path)
            else:
                self.rebuild_graph_index(save=True)
                return

            self.graph_retriever = GraphRetriever(self.graph_store, self.vector_store.documents if self.vector_store else [])
        except Exception as e:
            logger.warning("加载图索引失败，将按需重建: %s", e)
            self.rebuild_graph_index(save=True)

    def _calculate_content_hash(self, content: str) -> str:
        return hashlib.md5(content.encode("utf-8")).hexdigest()

    @staticmethod
    def _extract_regulation_name_from_filename(filename: str) -> str:
        base_name = os.path.splitext(str(filename or "").strip())[0]
        if not base_name:
            return ""

        # 去掉常见版本后缀：例如 "（2023）"、"(2018版)"
        normalized = re.sub(r"[（(]\s*\d{4}[^）)]*[）)]\s*$", "", base_name).strip()
        return normalized or base_name

    @staticmethod
    def _extract_version_label_from_filename(filename: str) -> str:
        base_name = os.path.splitext(str(filename or "").strip())[0]
        if not base_name:
            return ""
        match = re.search(r"[（(]\s*([^（）()]{2,30})\s*[）)]\s*$", base_name)
        if not match:
            return ""
        return str(match.group(1) or "").strip()

    @staticmethod
    def _build_regulation_group_id(group_name: str) -> str:
        normalized = re.sub(r"\s+", "", str(group_name or "")).strip().lower()
        if not normalized:
            normalized = "unknown_regulation_group"
        digest = hashlib.md5(normalized.encode("utf-8")).hexdigest()[:12]
        return f"reg_{digest}"

    @staticmethod
    def _to_bool(value: Any) -> bool:
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.strip().lower() in {"1", "true", "yes", "y", "on"}
        return bool(value)

    @staticmethod
    def _normalize_knowledge_labels(raw_labels: Any) -> Dict[str, List[str]]:
        if not isinstance(raw_labels, dict):
            return {}

        normalized: Dict[str, List[str]] = {}
        for raw_key, raw_value in raw_labels.items():
            key = str(raw_key or "").strip()
            if not key:
                continue
            if isinstance(raw_value, list):
                values = [str(item or "").strip() for item in raw_value]
            elif raw_value is None:
                values = []
            else:
                values = [str(raw_value or "").strip()]
            values = [item for item in values if item]
            if values:
                normalized[key] = values
        return normalized

    def _resolve_regulation_group_meta(self, doc: Dict[str, Any]) -> Tuple[str, str, str]:
        doc_type = str(doc.get("doc_type", "") or "").strip()
        if doc_type not in REGULATION_DOC_TYPES:
            return "", "", ""

        enabled = self._to_bool(doc.get("enable_regulation_group", False))
        if not enabled:
            return "", "", ""

        group_id = str(doc.get("regulation_group_id", "") or "").strip()
        group_name = str(doc.get("regulation_group_name", "") or "").strip()
        version_label = str(doc.get("version_label", "") or "").strip()

        if group_id and not group_name:
            for record in self.metadata_store.documents.values():
                if str(record.regulation_group_id or "").strip() == group_id:
                    group_name = str(record.regulation_group_name or "").strip()
                    if group_name:
                        break

        if group_name and not group_id:
            group_id = self._build_regulation_group_id(group_name)

        if not group_name and group_id:
            group_name = group_id

        if not group_name and not group_id:
            inferred_name = self._extract_regulation_name_from_filename(str(doc.get("filename", "") or ""))
            if inferred_name:
                group_name = inferred_name
                group_id = self._build_regulation_group_id(group_name)

        if not version_label:
            version_label = self._extract_version_label_from_filename(str(doc.get("filename", "") or ""))

        return group_id, group_name, version_label

    def _backfill_regulation_groups_if_needed(self) -> None:
        changed = False
        for record in self.metadata_store.documents.values():
            doc_type = str(record.doc_type or "").strip()
            if doc_type not in REGULATION_DOC_TYPES:
                continue

            if not str(record.regulation_group_id or "").strip():
                inferred_name = self._extract_regulation_name_from_filename(record.filename)
                if inferred_name:
                    record.regulation_group_name = inferred_name
                    record.regulation_group_id = self._build_regulation_group_id(inferred_name)
                    changed = True

            if not str(record.version_label or "").strip():
                inferred_version = self._extract_version_label_from_filename(record.filename)
                if inferred_version:
                    record.version_label = inferred_version
                    changed = True

        if changed:
            self.metadata_store.save()

    @staticmethod
    def _chinese_numeral_to_int(raw: str) -> Optional[int]:
        token = str(raw or "").strip()
        if not token:
            return None
        if token.isdigit():
            return int(token)

        digit_map = {
            "零": 0,
            "〇": 0,
            "一": 1,
            "二": 2,
            "两": 2,
            "三": 3,
            "四": 4,
            "五": 5,
            "六": 6,
            "七": 7,
            "八": 8,
            "九": 9,
        }
        unit_map = {"十": 10, "百": 100, "千": 1000, "万": 10000}

        if all(ch in digit_map for ch in token):
            return int("".join(str(digit_map[ch]) for ch in token))

        total = 0
        section = 0
        number = 0
        seen = False
        for ch in token:
            if ch in digit_map:
                number = digit_map[ch]
                seen = True
                continue
            if ch in unit_map:
                seen = True
                unit = unit_map[ch]
                if unit == 10000:
                    section = (section + number) * unit
                    total += section
                    section = 0
                    number = 0
                else:
                    if number == 0:
                        number = 1
                    section += number * unit
                    number = 0
                continue
            return None

        if not seen:
            return None
        return total + section + number

    @classmethod
    def _extract_article_no(cls, text: str) -> Tuple[str, Optional[int]]:
        source = str(text or "").strip()
        if not source:
            return "", None

        match = re.search(r"第\s*([一二三四五六七八九十百千万零〇两\d]+)\s*条", source)
        if not match:
            return "", None
        token = str(match.group(1) or "").strip()
        article_no = f"第{token}条"
        article_number = cls._chinese_numeral_to_int(token)
        return article_no, article_number

    @staticmethod
    def _normalize_compare_text(text: str) -> str:
        return re.sub(r"\s+", "", str(text or "")).strip()

    @classmethod
    def _build_text_change_metrics(cls, old_text: str, new_text: str) -> Dict[str, Any]:
        old_norm = cls._normalize_compare_text(old_text)
        new_norm = cls._normalize_compare_text(new_text)
        matcher = SequenceMatcher(None, old_norm, new_norm)

        added = 0
        removed = 0
        replaced = 0
        for tag, i1, i2, j1, j2 in matcher.get_opcodes():
            if tag == "insert":
                added += (j2 - j1)
            elif tag == "delete":
                removed += (i2 - i1)
            elif tag == "replace":
                replaced += max(i2 - i1, j2 - j1)

        return {
            "similarity": round(float(matcher.ratio()), 4),
            "added_chars": int(added),
            "removed_chars": int(removed),
            "replaced_chars": int(replaced),
        }

    def _build_article_entries_from_chunks(self, chunks: List[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
        ordered_chunks = sorted(
            chunks or [],
            key=lambda c: (
                int(c.get("chunk_index", 0) or 0),
                int(c.get("global_index", 0) or 0),
            ),
        )

        entries: Dict[str, Dict[str, Any]] = {}
        for idx, chunk in enumerate(ordered_chunks):
            text = str(chunk.get("text", "") or "")
            metadata = chunk.get("metadata", {}) or {}
            header = str(metadata.get("header", "") or chunk.get("header", "") or "")
            first_line = str(text.splitlines()[0] if text else "")

            article_no, article_number = self._extract_article_no(header)
            if not article_no:
                article_no, article_number = self._extract_article_no(first_line)

            if article_number is not None:
                article_key = f"article:{article_number:05d}"
            elif article_no:
                article_key = f"article_label:{article_no}"
            else:
                chunk_id = str(chunk.get("chunk_id", "") or f"chunk_{idx}")
                fallback_header = header or first_line or chunk_id
                normalized_fallback = self._normalize_compare_text(fallback_header)[:48]
                article_key = f"section:{normalized_fallback}" if normalized_fallback else f"chunk:{chunk_id}"

            payload = entries.setdefault(
                article_key,
                {
                    "article_key": article_key,
                    "article_no": article_no,
                    "article_number": article_number,
                    "texts": [],
                    "page_nos": [],
                    "chunk_ids": [],
                    "order": idx,
                },
            )

            if article_no and not payload.get("article_no"):
                payload["article_no"] = article_no
            if article_number is not None and payload.get("article_number") is None:
                payload["article_number"] = article_number
            payload["order"] = min(int(payload.get("order", idx) or idx), idx)

            if text:
                payload["texts"].append(text)

            chunk_id = str(chunk.get("chunk_id", "") or "")
            if chunk_id:
                payload["chunk_ids"].append(chunk_id)

            page_nos = metadata.get("page_nos", []) or []
            for p in page_nos:
                try:
                    page_no = int(p)
                except (TypeError, ValueError):
                    continue
                if page_no not in payload["page_nos"]:
                    payload["page_nos"].append(page_no)

        for item in entries.values():
            item["page_nos"] = sorted(item.get("page_nos", []))
            item["chunk_ids"] = list(dict.fromkeys(item.get("chunk_ids", [])))
            item["text"] = "\n\n".join(t for t in item.get("texts", []) if t).strip()
            item.pop("texts", None)

        return entries

    def _extract_page_nos_and_clean_text(self, text: str) -> Tuple[str, List[int]]:
        page_numbers = [int(m.group(1)) for m in PAGE_PATTERN.finditer(text or "")]
        unique_pages = sorted(set(page_numbers))
        cleaned = PAGE_PATTERN.sub("", text or "")
        cleaned = re.sub(r"\n{3,}", "\n\n", cleaned).strip()
        return cleaned, unique_pages

    def _split_oversized_chunk_text(self, text: str, max_chars: int = EMBEDDING_SAFE_CHUNK_MAX_CHARS) -> List[str]:
        cleaned = str(text or "").strip()
        if not cleaned:
            return []
        if len(cleaned) <= max_chars:
            return [cleaned]

        pieces: List[str] = []
        remaining = cleaned
        separators = ["\n\n", "\n", "。", "；", "：", "，", "、", " "]

        while remaining:
            if len(remaining) <= max_chars:
                pieces.append(remaining.strip())
                break

            window = remaining[:max_chars]
            split_at = -1
            split_sep = ""
            min_cutoff = max_chars // 2
            for sep in separators:
                pos = window.rfind(sep)
                if pos >= min_cutoff and pos > split_at:
                    split_at = pos
                    split_sep = sep

            if split_at == -1:
                split_at = max_chars
                split_sep = ""
            else:
                split_at += len(split_sep)

            chunk_text = remaining[:split_at].strip()
            if not chunk_text:
                chunk_text = remaining[:max_chars].strip()
                split_at = max_chars

            pieces.append(chunk_text)
            remaining = remaining[split_at:].lstrip()

        return [piece for piece in pieces if piece]

    def _normalize_chunks(self, chunks: List[Dict[str, Any]], doc_id: str) -> List[Dict[str, Any]]:
        normalized = []
        seen_ids = set()

        for idx, chunk in enumerate(chunks):
            text = chunk.get("text", "")
            cleaned_text, page_nos = self._extract_page_nos_and_clean_text(text)
            if not cleaned_text:
                continue

            chunk_id = chunk.get("chunk_id") or f"{doc_id}_chunk_{idx}"
            chunk_id = str(chunk_id)
            split_texts = self._split_oversized_chunk_text(cleaned_text)
            if len(split_texts) > 1:
                logger.info(
                    "检测到超长分块并已自动拆分: filename=%s original_chunk_id=%s split_count=%s",
                    chunk.get("filename", ""),
                    chunk_id,
                    len(split_texts),
                )

            for split_idx, split_text in enumerate(split_texts):
                normalized_chunk = dict(chunk)
                normalized_chunk["text"] = split_text
                normalized_chunk["doc_id"] = doc_id

                next_chunk_id = chunk_id if len(split_texts) == 1 else f"{chunk_id}_part_{split_idx}"
                if next_chunk_id in seen_ids:
                    next_chunk_id = f"{next_chunk_id}_{idx}_{split_idx}"
                seen_ids.add(next_chunk_id)

                normalized_chunk["chunk_id"] = next_chunk_id
                normalized_chunk["chunk_index"] = len(normalized)
                if len(split_texts) > 1:
                    normalized_chunk["split_from_chunk_id"] = chunk_id
                    normalized_chunk["split_index"] = split_idx
                    normalized_chunk["split_count"] = len(split_texts)

                if page_nos:
                    normalized_chunk["page_nos"] = page_nos
                elif "page_nos" in normalized_chunk and not normalized_chunk.get("page_nos"):
                    normalized_chunk.pop("page_nos", None)

                normalized_chunk["char_count"] = len(split_text)
                normalized.append(normalized_chunk)

        return normalized

    def _normalize_vector_documents(self) -> bool:
        if not self.vector_store:
            return False

        changed = False
        per_doc_index = defaultdict(int)
        seen_chunk_ids = set()

        for i, doc in enumerate(self.vector_store.documents):
            doc_id = str(doc.get("doc_id") or f"unknown_doc_{i}")
            idx = per_doc_index[doc_id]
            per_doc_index[doc_id] += 1

            cleaned_text, page_nos = self._extract_page_nos_and_clean_text(doc.get("text", ""))
            if cleaned_text != doc.get("text", ""):
                doc["text"] = cleaned_text
                changed = True

            if page_nos and doc.get("page_nos") != page_nos:
                doc["page_nos"] = page_nos
                changed = True

            if not doc.get("doc_id"):
                doc["doc_id"] = doc_id
                changed = True

            normalized_labels = self._normalize_knowledge_labels(doc.get("knowledge_labels", {}))
            if doc.get("knowledge_labels") != normalized_labels:
                doc["knowledge_labels"] = normalized_labels
                changed = True

            old_chunk_id = doc.get("chunk_id")
            chunk_id = str(old_chunk_id) if old_chunk_id else f"{doc_id}_chunk_{idx}"
            if chunk_id in seen_chunk_ids:
                chunk_id = f"{chunk_id}_{idx}"
            seen_chunk_ids.add(chunk_id)

            if chunk_id != old_chunk_id:
                doc["chunk_id"] = chunk_id
                changed = True

            if doc.get("char_count") != len(doc.get("text", "")):
                doc["char_count"] = len(doc.get("text", ""))
                changed = True

            if "searchable" not in doc:
                doc["searchable"] = True
                changed = True

        return changed

    def _get_stored_document_chunks(self, doc_id: str) -> List[Dict[str, Any]]:
        preview_chunks = self._load_preview_chunks(doc_id)
        if preview_chunks is not None:
            return preview_chunks

        if not self.vector_store:
            try:
                self.load_vector_store(self.vector_store_path)
            except Exception:
                return []

        if not self.vector_store:
            return []

        chunks = self.vector_store.get_document_chunks(doc_id)
        if chunks:
            self._save_preview_chunks(doc_id, chunks)
        return chunks

    def _remove_document_from_index(self, doc_id: str) -> int:
        if not self.vector_store:
            try:
                self.load_vector_store(self.vector_store_path)
            except Exception:
                return 0

        if not self.vector_store:
            return 0

        return self.vector_store.remove_document_chunks(doc_id)

    def _log_oversized_chunks(self, chunks: List[Dict[str, Any]], max_chars: int = EMBEDDING_INPUT_MAX_CHARS) -> None:
        oversized = []
        for chunk in chunks:
            text = str(chunk.get("text", "") or "")
            text_len = len(text)
            if text_len <= max_chars:
                continue
            oversized.append((chunk, text_len))

        if not oversized:
            return

        logger.warning(
            "检测到 %s 个超长分块(> %s 字符)，后续嵌入调用可能失败",
            len(oversized),
            max_chars,
        )
        for chunk, text_len in oversized:
            logger.warning(
                "超长分块详情: filename=%s title=%s doc_id=%s chunk_id=%s semantic_boundary=%s header=%s section_path=%s char_count=%s",
                chunk.get("filename", ""),
                chunk.get("title", ""),
                chunk.get("doc_id", ""),
                chunk.get("chunk_id", ""),
                chunk.get("semantic_boundary", ""),
                chunk.get("header", ""),
                " > ".join(chunk.get("section_path", []) or []),
                text_len,
            )

    def process_documents(self, documents: List[Dict[str, Any]], save_after_processing: bool = True) -> Dict:
        processed_count = 0
        skipped_count = 0
        updated_count = 0
        pending_new_entries: List[Dict[str, Any]] = []
        pending_existing_updates: List[Dict[str, Any]] = []
        pending_index_entries: List[Dict[str, Any]] = []
        remove_from_index_ids: List[str] = []

        for doc in documents:
            content = doc["text"]
            content_hash = self._calculate_content_hash(content)
            doc_id = content_hash[:16]
            group_id, group_name, version_label = self._resolve_regulation_group_meta(doc)
            storage_file_id = str(doc.get("storage_file_id", "") or "").strip()
            searchable = self._to_bool(doc.get("searchable", True))
            knowledge_labels = self._normalize_knowledge_labels(doc.get("knowledge_labels", {}))
            doc["knowledge_labels"] = knowledge_labels
            doc["doc_id"] = doc_id

            existing = self.metadata_store.get_document(doc_id)
            chunks = self.chunker.chunk_documents([doc])
            chunks = self._normalize_chunks(chunks, doc_id)
            for chunk in chunks:
                chunk["searchable"] = searchable
                chunk["status"] = "active"
                chunk["knowledge_labels"] = knowledge_labels
            self._log_oversized_chunks(chunks)

            if not chunks:
                logger.warning("文档未生成有效分块: %s", doc.get("filename", "unknown"))
                continue

            self._save_full_text(doc_id, content)
            self._save_preview_chunks(doc_id, chunks)

            if existing and existing.status == "active":
                was_searchable = bool(getattr(existing, "searchable", True))
                if searchable and not was_searchable:
                    pending_index_entries.append({
                        "doc_id": doc_id,
                        "chunks": chunks,
                    })
                elif was_searchable and not searchable:
                    remove_from_index_ids.append(doc_id)

                pending_existing_updates.append({
                    "existing": existing,
                    "doc": doc,
                    "doc_id": doc_id,
                    "chunks": chunks,
                    "group_id": group_id,
                    "group_name": group_name,
                    "version_label": version_label,
                    "storage_file_id": storage_file_id,
                    "searchable": searchable,
                    "knowledge_labels": knowledge_labels,
                })
                continue

            entry = {
                "doc": doc,
                "doc_id": doc_id,
                "content": content,
                "content_hash": content_hash,
                "chunks": chunks,
                "group_id": group_id,
                "group_name": group_name,
                "version_label": version_label,
                "storage_file_id": storage_file_id,
                "searchable": searchable,
                "knowledge_labels": knowledge_labels,
            }
            pending_new_entries.append(entry)
            if searchable:
                pending_index_entries.append({
                    "doc_id": doc_id,
                    "chunks": chunks,
                })

        if pending_index_entries:
            all_chunks: List[Dict[str, Any]] = []
            for entry in pending_index_entries:
                all_chunks.extend(entry["chunks"])

            texts = [c["text"] for c in all_chunks]
            embeddings = self.embedding_provider.get_embeddings(texts)

            if self.vector_store is None:
                if os.path.exists(f"{self.vector_store_path}.index"):
                    self.load_vector_store(self.vector_store_path)
                else:
                    self.dimension = len(embeddings[0]) if embeddings else 1024
                    self.vector_store = VectorStore(dimension=self.dimension)

            self.vector_store.add_embeddings(embeddings, all_chunks)
        
        index_changed = bool(pending_index_entries)
        for doc_id in list(dict.fromkeys(remove_from_index_ids)):
            removed = self._remove_document_from_index(doc_id)
            if removed > 0:
                index_changed = True

        metadata_dirty = False
        for entry in pending_existing_updates:
            existing = entry["existing"]
            doc = entry["doc"]
            doc_id = entry["doc_id"]
            storage_file_id = entry["storage_file_id"]

            metadata_changed = False
            existing_path = str(existing.file_path or "").strip()
            if (not existing_path or not os.path.exists(existing_path)) and not storage_file_id:
                persisted = self._persist_original_file(
                    doc_id=doc_id,
                    source_path=doc.get("file_path", ""),
                    filename=doc.get("filename", ""),
                )
                if persisted and existing.file_path != persisted:
                    existing.file_path = persisted
                    metadata_changed = True

            next_filename = str(doc.get("filename", "unknown") or "unknown")
            if existing.filename != next_filename:
                existing.filename = next_filename
                metadata_changed = True

            next_chunk_count = len(entry["chunks"])
            if existing.chunk_count != next_chunk_count:
                existing.chunk_count = next_chunk_count
                metadata_changed = True

            if existing.searchable != bool(entry["searchable"]):
                existing.searchable = bool(entry["searchable"])
                metadata_changed = True

            if storage_file_id and existing.storage_file_id != storage_file_id:
                existing.storage_file_id = storage_file_id
                metadata_changed = True
            if existing.knowledge_labels != entry["knowledge_labels"]:
                existing.knowledge_labels = dict(entry["knowledge_labels"])
                metadata_changed = True
            if entry["group_id"] and existing.regulation_group_id != entry["group_id"]:
                existing.regulation_group_id = entry["group_id"]
                metadata_changed = True
            if entry["group_name"] and existing.regulation_group_name != entry["group_name"]:
                existing.regulation_group_name = entry["group_name"]
                metadata_changed = True
            if entry["version_label"] and existing.version_label != entry["version_label"]:
                existing.version_label = entry["version_label"]
                metadata_changed = True

            if metadata_changed:
                metadata_dirty = True
                updated_count += 1
                logger.info("更新文档: %s", next_filename)
            else:
                skipped_count += 1
                logger.info("文档已存在，跳过: %s", next_filename)

        for entry in pending_new_entries:
            doc = entry["doc"]
            storage_file_id = entry["storage_file_id"]
            original_file_path = ""
            if not storage_file_id:
                original_file_path = self._persist_original_file(
                    doc_id=entry["doc_id"],
                    source_path=doc.get("file_path", ""),
                    filename=doc.get("filename", ""),
                ) or ""
            record = DocumentRecord(
                doc_id=entry["doc_id"],
                filename=doc.get("filename", "unknown"),
                content_hash=entry["content_hash"],
                file_path=original_file_path or ("" if storage_file_id else doc.get("file_path", "")),
                file_size=len(entry["content"].encode("utf-8")),
                doc_type=doc.get("doc_type", "unknown"),
                upload_time=datetime.now().isoformat(),
                chunk_count=len(entry["chunks"]),
                searchable=bool(entry["searchable"]),
                regulation_group_id=str(entry.get("group_id", "") or ""),
                regulation_group_name=str(entry.get("group_name", "") or ""),
                version_label=str(entry.get("version_label", "") or ""),
                storage_file_id=storage_file_id,
                knowledge_labels=dict(entry.get("knowledge_labels", {}) or {}),
            )

            is_new = self.metadata_store.add_document(record, save=False)
            metadata_dirty = True
            if is_new:
                processed_count += 1
                logger.info("新增文档: %s, chunks: %s, searchable=%s", doc.get("filename", "unknown"), len(entry["chunks"]), bool(entry["searchable"]))
            else:
                updated_count += 1
                logger.info("更新文档: %s", doc.get("filename", "unknown"))

        if metadata_dirty:
            self.metadata_store.save()

        if self.vector_store and index_changed:
            self.retriever = VectorRetriever(self.vector_store, self.embedding_provider)
            self._normalize_vector_documents()
            self.rebuild_graph_index(save=save_after_processing)

        if save_after_processing and self.vector_store and index_changed:
            self.save_vector_store(self.vector_store_path)

        return {
            "processed": processed_count,
            "skipped": skipped_count,
            "updated": updated_count,
            "total_chunks": sum(c.chunk_count for c in self.metadata_store.list_documents()),
        }

    def _search_vector_raw(
        self,
        query: str,
        top_k: int,
        doc_types: List[str] = None,
        titles: List[str] = None,
        knowledge_filters: Optional[Dict[str, List[str]]] = None,
    ) -> List[Dict[str, Any]]:
        results = self.retriever.search(
            query,
            top_k=top_k,
            doc_types=doc_types,
            titles=titles,
            knowledge_filters=self._normalize_knowledge_labels(knowledge_filters),
        )
        formatted = []
        for r in results:
            doc = r.metadata or {}
            if doc.get("status") == "deleted":
                continue
            if doc.get("searchable") is False:
                continue
            if not doc.get("text"):
                continue
            formatted.append({
                "document": doc,
                "score": float(r.score),
                "vector_score": float(r.score),
            })
        return formatted

    def _search_graph_raw(
        self,
        query: str,
        top_k: int,
        doc_types: List[str] = None,
        knowledge_filters: Optional[Dict[str, List[str]]] = None,
        graph_hops: int = 2,
    ) -> List[Dict[str, Any]]:
        self._ensure_graph_index()
        if not self.graph_retriever:
            return []

        results = self.graph_retriever.search(
            query,
            top_k=top_k,
            doc_types=doc_types,
            knowledge_filters=self._normalize_knowledge_labels(knowledge_filters),
            hops=graph_hops,
        )
        formatted = []
        for r in results:
            doc = r.metadata or {}
            if doc.get("status") == "deleted":
                continue
            if doc.get("searchable") is False:
                continue
            if not doc.get("text"):
                continue
            formatted.append({
                "document": doc,
                "score": float(r.score),
                "graph_score": float(r.score),
            })
        return formatted

    def _normalized_score_map(self, keyed_scores: Dict[str, float]) -> Dict[str, float]:
        if not keyed_scores:
            return {}

        values = list(keyed_scores.values())
        min_v, max_v = min(values), max(values)
        if abs(max_v - min_v) < 1e-9:
            return {k: 1.0 for k in keyed_scores.keys()}
        return {k: (v - min_v) / (max_v - min_v) for k, v in keyed_scores.items()}

    def _result_key(self, doc: Dict[str, Any]) -> str:
        chunk_id = doc.get("chunk_id")
        if chunk_id:
            return f"chunk:{chunk_id}"
        fallback = f"{doc.get('doc_id','')}|{doc.get('filename','')}|{hash(doc.get('text',''))}"
        return f"fallback:{fallback}"

    def _fuse_hybrid_results(
        self,
        vector_results: List[Dict[str, Any]],
        graph_results: List[Dict[str, Any]],
        alpha: float,
    ) -> List[Dict[str, Any]]:
        alpha = max(0.0, min(1.0, alpha))

        merged: Dict[str, Dict[str, Any]] = {}
        vector_scores: Dict[str, float] = {}
        graph_scores: Dict[str, float] = {}

        for item in vector_results:
            key = self._result_key(item["document"])
            merged.setdefault(key, {"document": item["document"]})
            vector_scores[key] = max(vector_scores.get(key, float("-inf")), float(item.get("vector_score", item.get("score", 0.0))))

        for item in graph_results:
            key = self._result_key(item["document"])
            merged.setdefault(key, {"document": item["document"]})
            graph_scores[key] = max(graph_scores.get(key, float("-inf")), float(item.get("graph_score", item.get("score", 0.0))))

        v_norm = self._normalized_score_map(vector_scores)
        g_norm = self._normalized_score_map(graph_scores)

        fused = []
        for key, payload in merged.items():
            v = v_norm.get(key, 0.0)
            g = g_norm.get(key, 0.0)
            score = alpha * v + (1.0 - alpha) * g
            fused.append(
                {
                    "document": payload["document"],
                    "score": score,
                    "vector_score": vector_scores.get(key),
                    "graph_score": graph_scores.get(key),
                }
            )

        fused.sort(key=lambda x: x["score"], reverse=True)
        return fused

    def search(
        self,
        query: str,
        top_k: int = 5,
        use_rerank: bool = False,
        rerank_top_k: int = 10,
        doc_types: List[str] = None,
        titles: List[str] = None,
        knowledge_filters: Optional[Dict[str, List[str]]] = None,
        use_graph: bool = False,
        retrieval_mode: str = "vector",
        graph_top_k: int = 12,
        graph_hops: int = 2,
        hybrid_alpha: float = 0.65,
    ) -> List[Dict[str, Any]]:
        self._ensure_vector_store()

        mode = (retrieval_mode or "vector").lower()
        if use_graph and mode == "vector":
            mode = "hybrid"
        if mode not in {"vector", "hybrid", "graph"}:
            mode = "vector"

        initial_top_k = max(top_k * 2, rerank_top_k) if use_rerank else top_k

        vector_results: List[Dict[str, Any]] = []
        graph_results: List[Dict[str, Any]] = []

        if mode in {"vector", "hybrid"}:
            vector_results = self._search_vector_raw(
                query,
                top_k=max(initial_top_k, top_k),
                doc_types=doc_types,
                titles=titles,
                knowledge_filters=knowledge_filters,
            )

        if mode in {"graph", "hybrid"}:
            graph_results = self._search_graph_raw(
                query,
                top_k=max(graph_top_k, top_k),
                doc_types=doc_types,
                knowledge_filters=knowledge_filters,
                graph_hops=graph_hops,
            )

        if mode == "vector":
            initial_results = vector_results
        elif mode == "graph":
            initial_results = graph_results
        else:
            initial_results = self._fuse_hybrid_results(vector_results, graph_results, alpha=hybrid_alpha)

        if use_rerank and self.rerank_provider and initial_results:
            docs = [r["document"]["text"] for r in initial_results]
            reranked = self.rerank_provider.rerank(query, docs, top_k=min(len(docs), rerank_top_k))

            final_results = []
            for item in reranked[:top_k]:
                idx = item["index"]
                if idx < len(initial_results):
                    base = initial_results[idx]
                    result = {
                        "score": item["relevance_score"],
                        "document": base["document"],
                        "original_score": base.get("score"),
                    }
                    if base.get("vector_score") is not None:
                        result["vector_score"] = base.get("vector_score")
                    if base.get("graph_score") is not None:
                        result["graph_score"] = base.get("graph_score")
                    final_results.append(result)
            return final_results

        return initial_results[:top_k]

    def search_with_intent(
        self,
        query: str,
        use_rerank: bool = True,
        retrieval_overrides: Dict[str, Any] = None,
    ) -> Dict[str, Any]:
        params = self.router.get_routed_params(
            query,
            use_rerank=use_rerank,
            retrieval_overrides=retrieval_overrides,
        )
        search_results = self.search(
            query,
            top_k=params["top_k"],
            use_rerank=params["use_rerank"],
            rerank_top_k=params["rerank_top_k"],
            doc_types=params["doc_types"],
            knowledge_filters=params.get("knowledge_filters"),
            use_graph=params["use_graph"],
            retrieval_mode=params["retrieval_mode"],
            graph_top_k=params["graph_top_k"],
            graph_hops=params["graph_hops"],
            hybrid_alpha=params["hybrid_alpha"],
        )
        return {
            "query": query,
            "intent": params["intent"],
            "intent_reason": params["reason"],
            "suggested_top_k": params["top_k"],
            "retrieval_mode": params["retrieval_mode"],
            "graph_top_k": params["graph_top_k"],
            "graph_hops": params["graph_hops"],
            "hybrid_alpha": params["hybrid_alpha"],
            "search_results": search_results,
        }

    def search_with_llm_answer(
        self,
        query: str,
        top_k: int = 5,
        use_rerank: bool = True,
        rerank_top_k: int = 10,
        retrieval_overrides: Dict[str, Any] = None,
    ) -> Dict[str, Any]:
        if not self.llm_provider:
            raise ValueError("LLM功能未启用，请在初始化时传入llm_provider")

        params = self.router.get_routed_params(
            query,
            default_top_k=top_k,
            use_rerank=use_rerank,
            rerank_top_k=rerank_top_k,
            retrieval_overrides=retrieval_overrides,
        )

        search_results = self.search(
            query,
            top_k=params["top_k"],
            use_rerank=params["use_rerank"],
            rerank_top_k=params["rerank_top_k"],
            doc_types=params["doc_types"],
            knowledge_filters=params.get("knowledge_filters"),
            use_graph=params["use_graph"],
            retrieval_mode=params["retrieval_mode"],
            graph_top_k=params["graph_top_k"],
            graph_hops=params["graph_hops"],
            hybrid_alpha=params["hybrid_alpha"],
        )

        context_pack = self.build_contexts_and_citations(search_results)
        contexts = context_pack["contexts"]
        citations = context_pack["citations"]

        llm_result = self.llm_provider.generate_answer(query, contexts)

        return {
            "query": query,
            "intent": params["intent"],
            "intent_reason": params["reason"],
            "answer": llm_result["answer"],
            "contexts": contexts,
            "contexts_used": len(contexts),
            "search_results": search_results,
            "citations": citations,
            "llm_usage": llm_result.get("usage", {}),
            "model": llm_result.get("model", ""),
            "retrieval_mode": params["retrieval_mode"],
            "graph_top_k": params["graph_top_k"],
            "graph_hops": params["graph_hops"],
            "hybrid_alpha": params["hybrid_alpha"],
        }

    def _try_load_graph_store_only(self) -> bool:
        if self.graph_store.nodes:
            return True

        graph_path = self._graph_store_path()
        if not os.path.exists(graph_path):
            return False

        try:
            self.graph_store.load(graph_path)
            return bool(self.graph_store.nodes)
        except Exception as e:
            logger.warning("加载图索引用于引用证据失败: %s", e)
            return False

    def _build_incoming_edge_index(self) -> Dict[str, List[Tuple[str, Dict[str, Any]]]]:
        incoming_index: Dict[str, List[Tuple[str, Dict[str, Any]]]] = defaultdict(list)
        for source, neighbors in self.graph_store.edges.items():
            source_id = str(source)
            for edge in neighbors:
                target = str(edge.get("target", ""))
                if not target:
                    continue
                incoming_index[target].append((source_id, edge))
        return incoming_index

    def _decorate_node_by_id(self, node_id: str) -> Dict[str, Any]:
        node = self.graph_store.get_node(node_id)
        if node:
            return self._decorate_node(node)
        return {
            "id": node_id,
            "type": "",
            "name": node_id,
            "type_label": "",
            "name_label": node_id,
            "attrs": {},
        }

    def _build_path_edge_payload(
        self,
        source_id: str,
        target_id: str,
        edge: Dict[str, Any],
        direction: str,
    ) -> Dict[str, Any]:
        source_node = self.graph_store.get_node(source_id) or {}
        source_name = str(source_node.get("name", source_id))
        source_type = str(source_node.get("type", ""))

        target_node = self.graph_store.get_node(target_id) or {}
        target_name = str(target_node.get("name", target_id))
        target_type = str(target_node.get("type", ""))

        relation = str(edge.get("relation", ""))

        return {
            "source": source_id,
            "source_name": source_name,
            "source_name_label": self._label_node_name(source_type, source_name, attrs=source_node.get("attrs", {})),
            "source_type": source_type,
            "source_type_label": entity_type_label(source_type),
            "target": target_id,
            "target_name": target_name,
            "target_name_label": self._label_node_name(target_type, target_name, attrs=target_node.get("attrs", {})),
            "target_type": target_type,
            "target_type_label": entity_type_label(target_type),
            "relation": relation,
            "relation_label": relation_label(relation),
            "weight": float(edge.get("weight", 1.0)),
            "attrs": edge.get("attrs", {}),
            "direction": direction,
            "is_evidence_edge": self._is_evidence_node_type(source_type) or self._is_evidence_node_type(target_type),
        }

    def _build_path_text(self, path_nodes: List[Dict[str, Any]], path_edges: List[Dict[str, Any]]) -> str:
        if not path_nodes:
            return ""

        first = path_nodes[0]
        first_name = str(first.get("name_label") or first.get("name") or first.get("id") or "")
        parts = [first_name]

        for idx, edge in enumerate(path_edges):
            if idx + 1 >= len(path_nodes):
                break
            relation_name = str(edge.get("relation_label") or edge.get("relation") or "关联")
            if edge.get("direction") == "reverse":
                relation_name = f"{relation_name}(逆向)"
            target = path_nodes[idx + 1]
            target_name = str(target.get("name_label") or target.get("name") or target.get("id") or "")
            parts.append(f" -[{relation_name}]- {target_name}")

        return "".join(parts)

    def _find_shortest_path(
        self,
        source_id: str,
        target_id: str,
        max_hops: int,
        incoming_index: Dict[str, List[Tuple[str, Dict[str, Any]]]],
        include_evidence_nodes: bool = True,
    ) -> Optional[Dict[str, Any]]:
        if source_id not in self.graph_store.nodes or target_id not in self.graph_store.nodes:
            return None

        if source_id == target_id:
            node_payload = self._decorate_node_by_id(source_id)
            return {
                "node_ids": [source_id],
                "nodes": [node_payload],
                "edges": [],
                "path_text": str(node_payload.get("name_label") or node_payload.get("name") or source_id),
                "hops": 0,
            }

        q = deque([source_id])
        depth: Dict[str, int] = {source_id: 0}
        parent: Dict[str, Tuple[str, Dict[str, Any], str]] = {}

        while q:
            current = q.popleft()
            current_depth = depth.get(current, 0)
            if current_depth >= max_hops:
                continue

            for edge in self.graph_store.neighbors(current):
                nxt = str(edge.get("target", ""))
                if not nxt or nxt not in self.graph_store.nodes:
                    continue
                if nxt in depth:
                    continue
                if not include_evidence_nodes:
                    nxt_node = self.graph_store.get_node(nxt) or {}
                    nxt_type = str(nxt_node.get("type", ""))
                    if self._is_evidence_node_type(nxt_type):
                        continue

                depth[nxt] = current_depth + 1
                parent[nxt] = (current, edge, "forward")
                if nxt == target_id:
                    q.clear()
                    break
                q.append(nxt)

            if target_id in parent:
                break

            for prev_id, edge in incoming_index.get(current, []):
                if not prev_id or prev_id not in self.graph_store.nodes:
                    continue
                if prev_id in depth:
                    continue
                if not include_evidence_nodes:
                    prev_node = self.graph_store.get_node(prev_id) or {}
                    prev_type = str(prev_node.get("type", ""))
                    if self._is_evidence_node_type(prev_type):
                        continue

                depth[prev_id] = current_depth + 1
                parent[prev_id] = (current, edge, "reverse")
                if prev_id == target_id:
                    q.clear()
                    break
                q.append(prev_id)

            if target_id in parent:
                break

        if target_id not in parent:
            return None

        node_ids = [target_id]
        step_records: List[Tuple[str, str, Dict[str, Any], str]] = []
        cursor = target_id

        while cursor != source_id:
            parent_node, edge, direction = parent[cursor]
            step_records.append((parent_node, cursor, edge, direction))
            node_ids.append(parent_node)
            cursor = parent_node

        node_ids.reverse()
        step_records.reverse()

        path_nodes = [self._decorate_node_by_id(node_id) for node_id in node_ids]
        path_edges = [
            self._build_path_edge_payload(step_source, step_target, edge, direction)
            for step_source, step_target, edge, direction in step_records
        ]
        path_text = self._build_path_text(path_nodes, path_edges)

        return {
            "node_ids": node_ids,
            "nodes": path_nodes,
            "edges": path_edges,
            "path_text": path_text,
            "hops": len(path_edges),
        }

    def _resolve_graph_node(
        self,
        node_id: str = "",
        query: str = "",
        max_candidates: int = 5,
        include_evidence_nodes: bool = True,
    ) -> Tuple[str, List[Dict[str, Any]]]:
        normalized_node_id = str(node_id or "").strip()
        if normalized_node_id and normalized_node_id in self.graph_store.nodes:
            selected = self.graph_store.nodes[normalized_node_id]
            selected_type = str(selected.get("type", ""))
            if not include_evidence_nodes and self._is_evidence_node_type(selected_type):
                return "", []
            return normalized_node_id, [{**self._decorate_node(selected), "score": 1.0}]

        query_text = str(query or "").strip()
        if not query_text:
            return "", []

        candidates: List[Dict[str, Any]] = []
        matches = self.graph_store.find_nodes_by_query(query_text, max_nodes=max_candidates)
        for match in matches:
            match_id = str(match.get("node_id", ""))
            if not match_id:
                continue
            node = self.graph_store.get_node(match_id)
            if not node:
                continue
            node_type = str(node.get("type", ""))
            if not include_evidence_nodes and self._is_evidence_node_type(node_type):
                continue
            candidates.append({**self._decorate_node(node), "score": float(match.get("score", 0.0))})

        selected_id = str(candidates[0].get("id", "")) if candidates else ""
        return selected_id, candidates

    def _resolve_query_seed_matches(self, query: str, max_nodes: int = 8) -> List[Dict[str, Any]]:
        query_text = str(query or "").strip()
        if not query_text:
            return []

        matched = []
        for item in self.graph_store.find_nodes_by_query(query_text, max_nodes=max_nodes):
            node_id = str(item.get("node_id", ""))
            if not node_id:
                continue
            node = self.graph_store.get_node(node_id)
            if not node:
                continue
            matched.append(
                {
                    "node_id": node_id,
                    "score": float(item.get("score", 0.0)),
                    "node": node,
                }
            )
        return matched

    def _build_graph_evidence_for_chunk(
        self,
        chunk_id: str,
        seed_matches: List[Dict[str, Any]],
        incoming_index: Dict[str, List[Tuple[str, Dict[str, Any]]]],
        max_hops: int = 4,
    ) -> Optional[Dict[str, Any]]:
        if not chunk_id or not seed_matches:
            return None

        chunk_node_id = f"{ontology.ENTITY_CHUNK}:{chunk_id}"
        if chunk_node_id not in self.graph_store.nodes:
            return None

        best_path: Optional[Dict[str, Any]] = None
        best_seed: Optional[Dict[str, Any]] = None

        for seed in seed_matches:
            seed_id = str(seed.get("node_id", ""))
            if not seed_id:
                continue
            path = self._find_shortest_path(seed_id, chunk_node_id, max_hops=max_hops, incoming_index=incoming_index)
            if not path:
                continue

            if best_path is None:
                best_path = path
                best_seed = seed
                continue

            prev_hops = int(best_path.get("hops", 10_000))
            curr_hops = int(path.get("hops", 10_000))
            prev_seed_score = float(best_seed.get("score", 0.0)) if best_seed else 0.0
            curr_seed_score = float(seed.get("score", 0.0))

            if curr_hops < prev_hops or (curr_hops == prev_hops and curr_seed_score > prev_seed_score):
                best_path = path
                best_seed = seed

        if not best_path or not best_seed:
            return None

        seed_node = best_seed.get("node") or {}
        seed_type = str(seed_node.get("type", ""))
        seed_name = str(seed_node.get("name", ""))

        return {
            "seed_node_id": str(best_seed.get("node_id", "")),
            "seed_name": seed_name,
            "seed_name_label": self._label_node_name(seed_type, seed_name),
            "seed_type": seed_type,
            "seed_type_label": entity_type_label(seed_type),
            "seed_score": float(best_seed.get("score", 0.0)),
            "hops": int(best_path.get("hops", 0)),
            "path_text": str(best_path.get("path_text", "")),
            "path_nodes": best_path.get("nodes", []),
            "path_edges": best_path.get("edges", []),
        }

    def build_contexts_and_citations(
        self,
        search_results: List[Dict[str, Any]],
        query: str = "",
    ) -> Dict[str, List[Dict[str, Any]]]:
        contexts: List[Dict[str, Any]] = []
        citations: List[Dict[str, Any]] = []
        evidence_cache: Dict[str, Optional[Dict[str, Any]]] = {}

        seed_matches: List[Dict[str, Any]] = []
        incoming_index: Dict[str, List[Tuple[str, Dict[str, Any]]]] = {}
        if query and self._try_load_graph_store_only():
            seed_matches = self._resolve_query_seed_matches(query, max_nodes=10)
            if seed_matches:
                incoming_index = self._build_incoming_edge_index()

        for idx, res in enumerate(search_results, 1):
            doc = res.get("document", {})
            source_id = f"S{idx}"
            raw_text = doc.get("text", "") or ""
            text_preview = raw_text[:220] + ("..." if len(raw_text) > 220 else "")
            chunk_id = str(doc.get("chunk_id", "") or "")

            graph_evidence = None
            if seed_matches and incoming_index and chunk_id:
                if chunk_id not in evidence_cache:
                    evidence_cache[chunk_id] = self._build_graph_evidence_for_chunk(
                        chunk_id=chunk_id,
                        seed_matches=seed_matches,
                        incoming_index=incoming_index,
                        max_hops=4,
                    )
                graph_evidence = evidence_cache.get(chunk_id)

            contexts.append(
                {
                    "source_id": source_id,
                    "text": raw_text,
                    "title": doc.get("title", ""),
                    "filename": doc.get("filename", ""),
                    "doc_type": doc.get("doc_type", ""),
                    "score": res.get("score", 0.0),
                    "doc_id": doc.get("doc_id", ""),
                    "chunk_id": doc.get("chunk_id", ""),
                    "page_nos": doc.get("page_nos", []),
                    "header": doc.get("header", ""),
                    "section_path": doc.get("section_path", []),
                    "knowledge_labels": self._normalize_knowledge_labels(doc.get("knowledge_labels", {})),
                    "vector_score": res.get("vector_score"),
                    "graph_score": res.get("graph_score"),
                }
            )

            citation_item = {
                "source_id": source_id,
                "doc_id": doc.get("doc_id", ""),
                "chunk_id": chunk_id,
                "filename": doc.get("filename", ""),
                "title": doc.get("title", ""),
                "doc_type": doc.get("doc_type", ""),
                "score": res.get("score", 0.0),
                "original_score": res.get("original_score"),
                "vector_score": res.get("vector_score"),
                "graph_score": res.get("graph_score"),
                "text_preview": text_preview,
                "page_nos": doc.get("page_nos", []),
                "header": doc.get("header", ""),
                "section_path": doc.get("section_path", []),
                "knowledge_labels": self._normalize_knowledge_labels(doc.get("knowledge_labels", {})),
            }
            if graph_evidence:
                citation_item["graph_evidence"] = graph_evidence
            citations.append(citation_item)

        return {"contexts": contexts, "citations": citations}

    def save_vector_store(self, filepath: str = None):
        if not self.vector_store:
            return
        self.vector_store.save(filepath or self.vector_store_path)

    def load_vector_store(self, filepath: str = None):
        path = filepath or self.vector_store_path
        self.vector_store = VectorStore(dimension=self.dimension or 1024)
        self.vector_store.load(path)
        self.dimension = self.vector_store.index.d

        changed = self._normalize_vector_documents()
        if changed:
            self.vector_store.save(path)

        self.retriever = VectorRetriever(self.vector_store, self.embedding_provider)

        if self.graph_retriever:
            self.graph_retriever.refresh_documents(self.vector_store.documents)

    def rebuild_graph_index(self, save: bool = True) -> Dict[str, Any]:
        if not self.vector_store:
            return {"nodes": 0, "edges": 0, "by_type": {}}

        builder = GraphBuilder()
        self.graph_store = builder.build(self.vector_store.documents)
        self.graph_retriever = GraphRetriever(self.graph_store, self.vector_store.documents)

        stats = self.graph_store.get_stats()

        if save:
            self.graph_store.save(self._graph_store_path())

        return stats

    def get_graph_stats(self) -> Dict[str, Any]:
        graph_path = self._graph_store_path()
        if not self.graph_store.nodes and os.path.exists(graph_path):
            try:
                self.graph_store.load(graph_path)
                if self.vector_store and not self.graph_retriever:
                    self.graph_retriever = GraphRetriever(self.graph_store, self.vector_store.documents)
            except Exception as e:
                logger.warning("加载图索引统计失败，将返回当前内存统计: %s", e)

        in_memory_stats = self.graph_store.get_stats()
        by_type = in_memory_stats.get("by_type", {})
        in_memory_stats["by_type_labels"] = {k: entity_type_label(k) for k in by_type.keys()}

        return {
            "graph_file_exists": os.path.exists(graph_path),
            "graph_path": graph_path,
            "in_memory": in_memory_stats,
        }

    def _ensure_graph_store_loaded(self):
        if self.graph_store.nodes:
            return

        graph_path = self._graph_store_path()
        if os.path.exists(graph_path):
            self.graph_store.load(graph_path)
            return

        self._ensure_vector_store()
        self.rebuild_graph_index(save=True)

    @staticmethod
    def _is_evidence_node_type(node_type: str) -> bool:
        return str(node_type or "") in EVIDENCE_NODE_TYPES

    @staticmethod
    def _format_pages(page_nos: List[Any], max_len: int = 3) -> str:
        values = []
        for p in page_nos or []:
            try:
                values.append(int(p))
            except (TypeError, ValueError):
                continue
        values = sorted(set(values))
        if not values:
            return ""
        if len(values) <= max_len:
            return "p." + ",".join(str(v) for v in values)
        return "p." + ",".join(str(v) for v in values[:max_len]) + "..."

    @staticmethod
    def _chunk_name_label(attrs: Dict[str, Any], fallback: str) -> str:
        filename = str(attrs.get("filename", "") or attrs.get("title", "") or "").strip()
        pages = RAGProcessor._format_pages(attrs.get("page_nos", []), max_len=3)
        header = str(attrs.get("header", "") or "").strip()
        semantic_boundary = str(attrs.get("semantic_boundary", "") or "").strip()
        text_preview = str(attrs.get("text_preview", "") or "").strip()

        parts = []
        if filename:
            parts.append(filename)
        if pages:
            parts.append(pages)
        if header:
            parts.append(header[:30])
        elif semantic_boundary:
            parts.append(semantic_boundary[:30])
        elif text_preview:
            parts.append(text_preview[:30])

        if parts:
            return " | ".join(parts)
        return fallback

    def _label_node_name(self, node_type: str, node_name: str, attrs: Optional[Dict[str, Any]] = None) -> str:
        attrs = attrs or {}
        if node_type == "doc_type":
            return doc_type_label(node_name)
        if node_type == "rectification_status":
            return RECTIFICATION_STATUS_LABELS.get(node_name, node_name)
        if node_type == ontology.ENTITY_CHUNK:
            return self._chunk_name_label(attrs, node_name)
        return node_name

    def _decorate_node(self, node: Dict[str, Any]) -> Dict[str, Any]:
        node_type_key = str(node.get("type", ""))
        node_name = str(node.get("name", ""))
        attrs = node.get("attrs", {}) or {}
        payload = {
            **node,
            "type_label": entity_type_label(node_type_key),
            "name_label": self._label_node_name(node_type_key, node_name, attrs=attrs),
            "is_evidence": self._is_evidence_node_type(node_type_key),
        }
        return payload

    def _build_edge_payload(self, source: str, edge: Dict[str, Any]) -> Dict[str, Any]:
        source_node = self.graph_store.get_node(source) or {}
        source_name = str(source_node.get("name", source))
        source_type = str(source_node.get("type", ""))

        target = str(edge.get("target", ""))
        target_node = self.graph_store.get_node(target) or {}
        target_name = str(target_node.get("name", target))
        target_type = str(target_node.get("type", ""))

        relation = str(edge.get("relation", ""))

        return {
            "source": source,
            "source_name": source_name,
            "source_name_label": self._label_node_name(source_type, source_name, attrs=source_node.get("attrs", {})),
            "source_type": source_type,
            "source_type_label": entity_type_label(source_type),
            "target": target,
            "target_name": target_name,
            "target_name_label": self._label_node_name(target_type, target_name, attrs=target_node.get("attrs", {})),
            "target_type": target_type,
            "target_type_label": entity_type_label(target_type),
            "relation": relation,
            "relation_label": relation_label(relation),
            "weight": float(edge.get("weight", 1.0)),
            "attrs": edge.get("attrs", {}),
            "is_evidence_edge": self._is_evidence_node_type(source_type) or self._is_evidence_node_type(target_type),
        }

    def get_graph_overview(self, top_n: int = 8) -> Dict[str, Any]:
        self._ensure_graph_store_loaded()
        safe_top_n = max(3, min(50, int(top_n)))

        stats = self.graph_store.get_stats()
        node_type_counts = stats.get("by_type", {})

        node_type_distribution = [
            {
                "type": t,
                "label": entity_type_label(t),
                "count": int(c),
            }
            for t, c in sorted(node_type_counts.items(), key=lambda item: item[1], reverse=True)
        ]

        relation_counts: Dict[str, int] = defaultdict(int)
        for neighbors in self.graph_store.edges.values():
            for edge in neighbors:
                rel = str(edge.get("relation", ""))
                if rel:
                    relation_counts[rel] += 1

        relation_distribution = [
            {
                "relation": rel,
                "label": relation_label(rel),
                "count": int(count),
            }
            for rel, count in sorted(relation_counts.items(), key=lambda item: item[1], reverse=True)[:safe_top_n]
        ]

        status_counts: Dict[str, int] = defaultdict(int)
        for node in self.graph_store.nodes.values():
            if str(node.get("type", "")) != "rectification_status":
                continue
            raw_name = str(node.get("name", ""))
            status_label = self._label_node_name("rectification_status", raw_name)
            status_counts[status_label] += 1

        rectification_status_distribution = [
            {
                "status": status,
                "label": status,
                "count": int(count),
            }
            for status, count in sorted(status_counts.items(), key=lambda item: item[1], reverse=True)
        ]

        department_issues: Dict[str, Set[str]] = defaultdict(set)
        for node_id, node in self.graph_store.nodes.items():
            if str(node.get("type", "")) != "issue":
                continue
            for edge in self.graph_store.neighbors(node_id):
                if str(edge.get("relation", "")) != "belongs_to_department":
                    continue
                target_id = str(edge.get("target", ""))
                target_node = self.graph_store.get_node(target_id) or {}
                if str(target_node.get("type", "")) != "department":
                    continue
                dept_name = str(target_node.get("name", ""))
                if dept_name:
                    department_issues[dept_name].add(node_id)

        department_issue_top = [
            {
                "department": dept,
                "issue_count": len(issue_ids),
            }
            for dept, issue_ids in sorted(
                department_issues.items(), key=lambda item: len(item[1]), reverse=True
            )[:safe_top_n]
        ]

        return {
            "nodes": int(stats.get("nodes", 0)),
            "edges": int(stats.get("edges", 0)),
            "node_type_distribution": node_type_distribution,
            "relation_distribution": relation_distribution,
            "rectification_status_distribution": rectification_status_distribution,
            "department_issue_top": department_issue_top,
        }

    def get_graph_node_detail(self, node_id: str, max_neighbors: int = 120) -> Dict[str, Any]:
        self._ensure_graph_store_loaded()
        safe_limit = max(20, min(300, int(max_neighbors)))

        node = self.graph_store.get_node(node_id)
        if not node:
            return {}

        outgoing_edges = []
        for edge in self.graph_store.neighbors(node_id):
            outgoing_edges.append(self._build_edge_payload(node_id, edge))
            if len(outgoing_edges) >= safe_limit:
                break

        incoming_edges = []
        for source, neighbors in self.graph_store.edges.items():
            for edge in neighbors:
                if str(edge.get("target", "")) != node_id:
                    continue
                incoming_edges.append(self._build_edge_payload(source, edge))
                if len(incoming_edges) >= safe_limit:
                    break
            if len(incoming_edges) >= safe_limit:
                break

        outgoing_edges.sort(key=lambda e: (str(e.get("relation", "")), str(e.get("target_name", ""))))
        incoming_edges.sort(key=lambda e: (str(e.get("relation", "")), str(e.get("source_name", ""))))

        neighbor_ids = {str(e.get("target", "")) for e in outgoing_edges}
        neighbor_ids.update({str(e.get("source", "")) for e in incoming_edges})
        neighbor_ids.discard(node_id)

        neighbors = []
        for neighbor_id in neighbor_ids:
            neighbor_node = self.graph_store.get_node(neighbor_id)
            if neighbor_node:
                neighbors.append(self._decorate_node(neighbor_node))
        neighbors.sort(key=lambda n: (str(n.get("type", "")), str(n.get("name", ""))))

        source_map: Dict[Tuple[str, str, str], Dict[str, Any]] = {}
        for edge in outgoing_edges + incoming_edges:
            attrs = edge.get("attrs", {}) or {}
            doc_id = str(attrs.get("doc_id", "") or "")
            chunk_id = str(attrs.get("source_chunk_id", "") or "")
            extractor = str(attrs.get("extractor", "") or "")
            confidence = float(attrs.get("confidence", 0.0) or 0.0)

            if not doc_id and not chunk_id:
                continue

            source_key = (doc_id, chunk_id, extractor)
            prev = source_map.get(source_key)
            if prev is None or confidence > float(prev.get("confidence", 0.0)):
                source_map[source_key] = {
                    "doc_id": doc_id,
                    "chunk_id": chunk_id,
                    "extractor": extractor,
                    "confidence": confidence,
                }

        sources = sorted(
            source_map.values(),
            key=lambda item: float(item.get("confidence", 0.0)),
            reverse=True,
        )

        source_chunks: List[Dict[str, Any]] = []
        if sources:
            if not self.vector_store:
                try:
                    self.load_vector_store(self.vector_store_path)
                except Exception:
                    pass

            if self.vector_store:
                docs_by_chunk: Dict[str, Dict[str, Any]] = {}
                for d in self.vector_store.documents:
                    chunk_id = str(d.get("chunk_id", "") or "")
                    if chunk_id and chunk_id not in docs_by_chunk:
                        docs_by_chunk[chunk_id] = d

                for src in sources:
                    chunk_id = str(src.get("chunk_id", "") or "")
                    if not chunk_id:
                        continue
                    doc = docs_by_chunk.get(chunk_id)
                    if not doc:
                        continue
                    text = str(doc.get("text", "") or "")
                    source_chunks.append(
                        {
                            "chunk_id": chunk_id,
                            "doc_id": doc.get("doc_id", ""),
                            "filename": doc.get("filename", ""),
                            "title": doc.get("title", ""),
                            "doc_type": doc.get("doc_type", ""),
                            "doc_type_label": doc_type_label(str(doc.get("doc_type", ""))),
                            "page_nos": doc.get("page_nos", []),
                            "header": doc.get("header", ""),
                            "text_preview": text[:220] + ("..." if len(text) > 220 else ""),
                        }
                    )

        return {
            "node": self._decorate_node(node),
            "outgoing_edges": outgoing_edges,
            "incoming_edges": incoming_edges,
            "neighbors": neighbors,
            "sources": sources,
            "source_chunks": source_chunks,
        }

    def list_graph_nodes(
        self,
        page: int = 1,
        page_size: int = 20,
        node_type: str = None,
        keyword: str = None,
        include_evidence_nodes: bool = False,
    ) -> Dict[str, Any]:
        self._ensure_graph_store_loaded()

        type_filter = entity_type_key((node_type or "").strip())
        keyword_filter = (keyword or "").strip().lower()

        type_options = sorted(
            {
                str(node.get("type", "")).strip()
                for node in self.graph_store.nodes.values()
                if str(node.get("type", "")).strip()
                and (include_evidence_nodes or not self._is_evidence_node_type(str(node.get("type", ""))))
            }
        )

        nodes = []
        for node in self.graph_store.nodes.values():
            node_type_value = str(node.get("type", ""))
            if not include_evidence_nodes and self._is_evidence_node_type(node_type_value):
                continue
            if type_filter and node.get("type") != type_filter:
                continue
            if keyword_filter:
                name = str(node.get("name", "")).lower()
                attrs_text = str(node.get("attrs", "")).lower()
                if keyword_filter not in name and keyword_filter not in attrs_text:
                    continue
            nodes.append(self._decorate_node(node))

        nodes.sort(key=lambda n: (str(n.get("type", "")), str(n.get("name", ""))))
        total = len(nodes)
        start = (page - 1) * page_size
        end = start + page_size

        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "nodes": nodes[start:end],
            "type_options": [{"value": key, "label": entity_type_label(key)} for key in type_options],
        }

    def list_graph_edges(
        self,
        page: int = 1,
        page_size: int = 20,
        relation: str = None,
        keyword: str = None,
        include_evidence_nodes: bool = False,
    ) -> Dict[str, Any]:
        self._ensure_graph_store_loaded()

        relation_filter = relation_key((relation or "").strip())
        keyword_filter = (keyword or "").strip().lower()
        relation_options_set = set()
        edge_agg: Dict[Tuple[str, str, str], Dict[str, Any]] = {}

        for source, neighbors in self.graph_store.edges.items():
            for edge in neighbors:
                edge_payload = self._build_edge_payload(source, edge)
                if not include_evidence_nodes:
                    if self._is_evidence_node_type(str(edge_payload.get("source_type", ""))):
                        continue
                    if self._is_evidence_node_type(str(edge_payload.get("target_type", ""))):
                        continue

                rel = edge.get("relation", "")
                relation_value = str(edge_payload.get("relation", "")).strip()
                if relation_value:
                    relation_options_set.add(relation_value)

                if relation_filter and rel != relation_filter:
                    continue

                if keyword_filter:
                    edge_text = (
                        f"{edge_payload.get('source_name', '')} "
                        f"{edge_payload.get('source_type', '')} "
                        f"{edge_payload.get('relation', '')} "
                        f"{edge_payload.get('target_name', '')} "
                        f"{edge_payload.get('target_type', '')}"
                    ).lower()
                    if keyword_filter not in edge_text:
                        continue

                signature = (
                    str(edge_payload.get("source", "")),
                    str(edge_payload.get("target", "")),
                    relation_value,
                )
                attrs = dict(edge_payload.get("attrs", {}) or {})
                confidence = float(attrs.get("confidence", 0.0) or 0.0)

                if signature not in edge_agg:
                    new_payload = {**edge_payload}
                    new_attrs = {**attrs, "evidence_count": 1}
                    if confidence > 0:
                        new_attrs["confidence_max"] = confidence
                    new_payload["attrs"] = new_attrs
                    edge_agg[signature] = new_payload
                else:
                    existing = edge_agg[signature]
                    existing_attrs = dict(existing.get("attrs", {}) or {})
                    existing_attrs["evidence_count"] = int(existing_attrs.get("evidence_count", 1)) + 1
                    prev_conf = float(existing_attrs.get("confidence_max", 0.0) or 0.0)
                    if confidence > prev_conf:
                        existing_attrs["confidence_max"] = confidence
                    existing["attrs"] = existing_attrs
                    if float(edge_payload.get("weight", 0.0) or 0.0) > float(existing.get("weight", 0.0) or 0.0):
                        existing["weight"] = edge_payload.get("weight", existing.get("weight", 1.0))

        relation_options = sorted(relation_options_set)
        edges = list(edge_agg.values())

        edges.sort(key=lambda e: (str(e.get("relation", "")), str(e.get("source_name", "")), str(e.get("target_name", ""))))
        total = len(edges)
        start = (page - 1) * page_size
        end = start + page_size

        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "edges": edges[start:end],
            "relation_options": [{"value": key, "label": relation_label(key)} for key in relation_options],
        }

    def get_graph_subgraph(
        self,
        query: str = None,
        node_ids: List[str] = None,
        hops: int = 2,
        max_nodes: int = 120,
        include_evidence_nodes: bool = False,
    ) -> Dict[str, Any]:
        self._ensure_graph_store_loaded()

        safe_hops = max(1, min(4, int(hops)))
        safe_max_nodes = max(20, min(300, int(max_nodes)))

        seed_nodes = set()
        for node_id in node_ids or []:
            if node_id in self.graph_store.nodes:
                node = self.graph_store.get_node(node_id) or {}
                if not include_evidence_nodes and self._is_evidence_node_type(str(node.get("type", ""))):
                    continue
                seed_nodes.add(node_id)

        if query:
            matches = self.graph_store.find_nodes_by_query(query, max_nodes=12)
            for m in matches:
                candidate_id = str(m.get("node_id", ""))
                if not candidate_id:
                    continue
                candidate_node = self.graph_store.get_node(candidate_id) or {}
                if not include_evidence_nodes and self._is_evidence_node_type(str(candidate_node.get("type", ""))):
                    continue
                seed_nodes.add(candidate_id)

        if not seed_nodes:
            return {
                "seed_nodes": [],
                "nodes": [],
                "edges": [],
                "hops": safe_hops,
                "max_nodes": safe_max_nodes,
            }

        visited = set(seed_nodes)
        q = deque([(node_id, 0) for node_id in seed_nodes])

        while q and len(visited) < safe_max_nodes:
            node_id, depth = q.popleft()
            if depth >= safe_hops:
                continue

            for edge in self.graph_store.neighbors(node_id):
                target = edge.get("target")
                if not target or target not in self.graph_store.nodes:
                    continue
                target_node = self.graph_store.get_node(target) or {}
                if not include_evidence_nodes and self._is_evidence_node_type(str(target_node.get("type", ""))):
                    continue
                if target in visited:
                    continue
                visited.add(target)
                q.append((target, depth + 1))
                if len(visited) >= safe_max_nodes:
                    break

        nodes = []
        for node_id in visited:
            if node_id not in self.graph_store.nodes:
                continue
            node = self.graph_store.nodes[node_id]
            nodes.append(self._decorate_node(node))
        nodes.sort(key=lambda n: (str(n.get("type", "")), str(n.get("name", ""))))

        edge_agg: Dict[Tuple[str, str, str], Dict[str, Any]] = {}
        for source in visited:
            for edge in self.graph_store.neighbors(source):
                target = edge.get("target")
                relation = edge.get("relation", "")
                if target not in visited:
                    continue
                source_node = self.graph_store.get_node(source) or {}
                target_node = self.graph_store.get_node(target) or {}
                if not include_evidence_nodes:
                    if self._is_evidence_node_type(str(source_node.get("type", ""))):
                        continue
                    if self._is_evidence_node_type(str(target_node.get("type", ""))):
                        continue
                signature = (source, target, relation)
                payload = self._build_edge_payload(source, edge)
                attrs = dict(payload.get("attrs", {}) or {})
                confidence = float(attrs.get("confidence", 0.0) or 0.0)

                if signature not in edge_agg:
                    new_attrs = {**attrs, "evidence_count": 1}
                    if confidence > 0:
                        new_attrs["confidence_max"] = confidence
                    edge_agg[signature] = {**payload, "attrs": new_attrs}
                else:
                    existing = edge_agg[signature]
                    existing_attrs = dict(existing.get("attrs", {}) or {})
                    existing_attrs["evidence_count"] = int(existing_attrs.get("evidence_count", 1)) + 1
                    prev_conf = float(existing_attrs.get("confidence_max", 0.0) or 0.0)
                    if confidence > prev_conf:
                        existing_attrs["confidence_max"] = confidence
                    existing["attrs"] = existing_attrs
                    if float(payload.get("weight", 0.0) or 0.0) > float(existing.get("weight", 0.0) or 0.0):
                        existing["weight"] = payload.get("weight", existing.get("weight", 1.0))

        edges = list(edge_agg.values())

        edges.sort(key=lambda e: (str(e.get("relation", "")), str(e.get("source_name", "")), str(e.get("target_name", ""))))

        return {
            "seed_nodes": list(seed_nodes),
            "nodes": nodes,
            "edges": edges,
            "hops": safe_hops,
            "max_nodes": safe_max_nodes,
        }

    def get_graph_path(
        self,
        source_node_id: str = "",
        target_node_id: str = "",
        source_query: str = "",
        target_query: str = "",
        max_hops: int = 4,
        max_candidates: int = 5,
        include_evidence_nodes: bool = False,
    ) -> Dict[str, Any]:
        self._ensure_graph_store_loaded()

        safe_hops = max(1, min(8, int(max_hops)))
        safe_candidates = max(1, min(10, int(max_candidates)))

        resolved_source_id, source_candidates = self._resolve_graph_node(
            node_id=source_node_id,
            query=source_query,
            max_candidates=safe_candidates,
            include_evidence_nodes=include_evidence_nodes,
        )
        resolved_target_id, target_candidates = self._resolve_graph_node(
            node_id=target_node_id,
            query=target_query,
            max_candidates=safe_candidates,
            include_evidence_nodes=include_evidence_nodes,
        )

        result: Dict[str, Any] = {
            "source_node": self._decorate_node_by_id(resolved_source_id) if resolved_source_id else None,
            "target_node": self._decorate_node_by_id(resolved_target_id) if resolved_target_id else None,
            "source_candidates": source_candidates,
            "target_candidates": target_candidates,
            "path_found": False,
            "path_nodes": [],
            "path_edges": [],
            "path_text": "",
            "hops": 0,
            "max_hops": safe_hops,
            "include_evidence_nodes": bool(include_evidence_nodes),
        }

        if not resolved_source_id or not resolved_target_id:
            return result

        incoming_index = self._build_incoming_edge_index()
        path = self._find_shortest_path(
            source_id=resolved_source_id,
            target_id=resolved_target_id,
            max_hops=safe_hops,
            incoming_index=incoming_index,
            include_evidence_nodes=include_evidence_nodes,
        )
        if not path:
            return result

        result.update(
            {
                "path_found": True,
                "path_nodes": path.get("nodes", []),
                "path_edges": path.get("edges", []),
                "path_text": path.get("path_text", ""),
                "hops": int(path.get("hops", 0)),
            }
        )
        return result

    def clear_vector_store(self):
        if self.vector_store:
            self.vector_store = VectorStore(dimension=self.dimension or 1024)
            self.retriever = VectorRetriever(self.vector_store, self.embedding_provider)

        self.graph_store.clear()
        self.graph_retriever = None
        graph_path = self._graph_store_path()
        if os.path.exists(graph_path):
            os.remove(graph_path)

    def process_documents_from_files(
        self,
        file_paths: List[str],
        save_after_processing: bool = True,
        doc_type: str = "internal_regulation",
        title: str = None,
        original_filenames: List[str] = None,
        error_collector: Optional[List[Dict[str, str]]] = None,
        extra_metadata: Optional[Dict[str, Any]] = None,
    ) -> Dict:
        from src.ingestion.parsers.document_processor import process_uploaded_documents

        processed_documents = process_uploaded_documents(
            file_paths,
            doc_type=doc_type,
            title=title,
            original_filenames=original_filenames,
            error_collector=error_collector,
            extra_metadata=extra_metadata,
        )
        if not processed_documents:
            return {"processed": 0, "skipped": 0, "updated": 0, "total_chunks": 0}
        return self.process_documents(processed_documents, save_after_processing=save_after_processing)

    def _refresh_metadata_store(self) -> None:
        try:
            self.metadata_store.refresh_if_changed()
        except Exception as e:
            logger.warning("刷新文档元数据失败: %s", e)

    @staticmethod
    def _record_matches_knowledge_filters(record: Any, knowledge_filters: Optional[Dict[str, List[str]]]) -> bool:
        if not knowledge_filters:
            return True

        raw_labels = getattr(record, "knowledge_labels", {}) or {}
        normalized_labels = RAGProcessor._normalize_knowledge_labels(raw_labels)
        normalized_filters = RAGProcessor._normalize_knowledge_labels(knowledge_filters)
        for key, expected_values in normalized_filters.items():
            if not expected_values:
                continue
            actual_values = normalized_labels.get(key, [])
            if not actual_values:
                return False
            if not set(actual_values).intersection(expected_values):
                return False
        return True

    def list_documents(
        self,
        doc_type: str = None,
        keyword: str = None,
        include_deleted: bool = False,
        knowledge_filters: Optional[Dict[str, List[str]]] = None,
    ) -> List[Dict]:
        self._refresh_metadata_store()
        self._backfill_regulation_groups_if_needed()
        status = None if include_deleted else "active"
        records = self.metadata_store.list_documents(doc_type=doc_type, status=status, keyword=keyword)
        normalized_filters = self._normalize_knowledge_labels(knowledge_filters)
        if normalized_filters:
            records = [r for r in records if self._record_matches_knowledge_filters(r, normalized_filters)]
        return [r.to_dict() for r in records]

    def list_regulation_groups(self, keyword: str = None, include_deleted: bool = False) -> List[Dict[str, Any]]:
        self._refresh_metadata_store()
        self._backfill_regulation_groups_if_needed()
        status = None if include_deleted else "active"
        records = self.metadata_store.list_documents(status=status)
        lowered_keyword = str(keyword or "").strip().lower()

        grouped: Dict[str, Dict[str, Any]] = {}
        for record in records:
            group_id = str(record.regulation_group_id or "").strip()
            if not group_id:
                continue

            group_name = str(record.regulation_group_name or "").strip() or group_id
            if lowered_keyword and lowered_keyword not in group_name.lower():
                continue

            payload = grouped.setdefault(
                group_id,
                {
                    "group_id": group_id,
                    "group_name": group_name,
                    "version_count": 0,
                    "latest_upload_time": "",
                    "latest_doc_id": "",
                    "latest_filename": "",
                },
            )
            payload["version_count"] += 1
            upload_time = str(record.upload_time or "")
            if upload_time >= str(payload.get("latest_upload_time", "")):
                payload["latest_upload_time"] = upload_time
                payload["latest_doc_id"] = record.doc_id
                payload["latest_filename"] = record.filename

        groups = list(grouped.values())
        groups.sort(key=lambda x: str(x.get("latest_upload_time", "")), reverse=True)
        return groups

    def list_regulation_versions(self, group_id: str, include_deleted: bool = False) -> List[Dict[str, Any]]:
        self._refresh_metadata_store()
        self._backfill_regulation_groups_if_needed()
        target_group_id = str(group_id or "").strip()
        if not target_group_id:
            return []

        status = None if include_deleted else "active"
        records = self.metadata_store.list_documents(status=status)
        matched = [
            r.to_dict()
            for r in records
            if str(r.regulation_group_id or "").strip() == target_group_id
        ]
        matched.sort(key=lambda x: str(x.get("upload_time", "")), reverse=True)
        return matched

    def compare_regulation_versions(
        self,
        left_doc_id: str,
        right_doc_id: str,
        include_unchanged: bool = False,
        keyword: str = "",
        limit: int = 500,
    ) -> Dict[str, Any]:
        self._refresh_metadata_store()
        self._backfill_regulation_groups_if_needed()

        left_id = str(left_doc_id or "").strip()
        right_id = str(right_doc_id or "").strip()
        if not left_id or not right_id:
            raise ValueError("缺少对比文档ID")
        if left_id == right_id:
            raise ValueError("请提供两个不同版本进行对比")

        left_record = self.metadata_store.get_document(left_id)
        right_record = self.metadata_store.get_document(right_id)
        if not left_record or left_record.status != "active":
            raise ValueError("左侧文档不存在或已删除")
        if not right_record or right_record.status != "active":
            raise ValueError("右侧文档不存在或已删除")

        left_chunks = self._get_stored_document_chunks(left_id)
        right_chunks = self._get_stored_document_chunks(right_id)
        if not left_chunks:
            raise ValueError("左侧文档没有可对比的分块")
        if not right_chunks:
            raise ValueError("右侧文档没有可对比的分块")

        left_entries = self._build_article_entries_from_chunks(left_chunks)
        right_entries = self._build_article_entries_from_chunks(right_chunks)
        all_keys = list(set(left_entries.keys()) | set(right_entries.keys()))

        def _safe_order(value: Any) -> int:
            try:
                return int(value)
            except (TypeError, ValueError):
                return 999999

        def _entry_sort_key(key: str) -> Tuple[int, int, int, str]:
            # 对比目录顺序与全屏预览保持一致：优先按右侧（新版本）原始目录顺序。
            right_item = right_entries.get(key)
            left_item = left_entries.get(key)
            right_order = _safe_order((right_item or {}).get("order", 999999))
            left_order = _safe_order((left_item or {}).get("order", 999999))
            if right_item:
                return (0, right_order, left_order, key)
            return (1, left_order, right_order, key)

        sorted_keys = sorted(all_keys, key=_entry_sort_key)
        lowered_keyword = str(keyword or "").strip().lower()

        summary = {
            "added": 0,
            "removed": 0,
            "modified": 0,
            "unchanged": 0,
            "total_articles": len(sorted_keys),
        }

        filtered_items: List[Dict[str, Any]] = []
        for key in sorted_keys:
            left_item = left_entries.get(key)
            right_item = right_entries.get(key)
            left_text = str((left_item or {}).get("text", "") or "")
            right_text = str((right_item or {}).get("text", "") or "")

            if left_item and right_item:
                left_norm = self._normalize_compare_text(left_text)
                right_norm = self._normalize_compare_text(right_text)
                status = "unchanged" if left_norm == right_norm else "modified"
            elif left_item:
                status = "removed"
            else:
                status = "added"

            summary[status] += 1

            if status == "unchanged" and not include_unchanged:
                continue

            article_no = str((right_item or {}).get("article_no", "") or (left_item or {}).get("article_no", "") or key)
            if lowered_keyword:
                haystack = (article_no + left_text + right_text).lower()
                if lowered_keyword not in haystack:
                    continue

            metrics = self._build_text_change_metrics(left_text, right_text) if left_item and right_item else None
            filtered_items.append(
                {
                    "article_key": key,
                    "article_no": article_no,
                    "article_number": (right_item or {}).get("article_number", (left_item or {}).get("article_number")),
                    "status": status,
                    "old_text": left_text,
                    "new_text": right_text,
                    "old_page_nos": (left_item or {}).get("page_nos", []),
                    "new_page_nos": (right_item or {}).get("page_nos", []),
                    "old_chunk_ids": (left_item or {}).get("chunk_ids", []),
                    "new_chunk_ids": (right_item or {}).get("chunk_ids", []),
                    "metrics": metrics,
                }
            )

        safe_limit = max(1, min(2000, int(limit or 500)))
        truncated = len(filtered_items) > safe_limit
        diffs = filtered_items[:safe_limit] if truncated else filtered_items

        return {
            "left_document": left_record.to_dict(),
            "right_document": right_record.to_dict(),
            "summary": summary,
            "diffs": diffs,
            "filtered_count": len(filtered_items),
            "returned_count": len(diffs),
            "truncated": truncated,
            "include_unchanged": bool(include_unchanged),
            "keyword": lowered_keyword,
        }

    def get_document_id_by_filename(self, filename: str, include_deleted: bool = False) -> Optional[Dict[str, Any]]:
        self._refresh_metadata_store()
        target_name = str(filename or "").strip()
        if not target_name:
            return None

        status = None if include_deleted else "active"
        records = self.metadata_store.list_documents(status=status)
        exact = [r for r in records if str(r.filename or "").strip() == target_name]
        if not exact:
            lowered = target_name.lower()
            exact = [r for r in records if str(r.filename or "").strip().lower() == lowered]
        if not exact:
            return None

        latest = exact[0]
        return {
            "filename": latest.filename,
            "doc_id": latest.doc_id,
            "upload_time": latest.upload_time,
            "status": latest.status,
            "matched_count": len(exact),
            "candidates": [
                {
                    "doc_id": r.doc_id,
                    "upload_time": r.upload_time,
                    "status": r.status,
                }
                for r in exact[:20]
            ],
        }

    def get_document_detail_by_filename(self, filename: str) -> Optional[Dict]:
        self._refresh_metadata_store()
        target_name = str(filename or "").strip()
        if not target_name:
            return None

        active_records = self.metadata_store.list_documents(status="active")
        exact = [r for r in active_records if str(r.filename or "").strip() == target_name]
        if not exact:
            lowered = target_name.lower()
            exact = [r for r in active_records if str(r.filename or "").strip().lower() == lowered]
        if not exact:
            return None

        # list_documents 已按 upload_time 倒序，取第一个即最新上传版本
        return self.get_document_detail(exact[0].doc_id)

    def get_document_detail(self, doc_id: str) -> Optional[Dict]:
        self._refresh_metadata_store()
        self._backfill_regulation_groups_if_needed()
        record = self.metadata_store.get_document(doc_id)
        if not record:
            return None

        detail = record.to_dict()
        file_path = str(detail.get("file_path", "") or "").strip()
        if file_path:
            if not os.path.isabs(file_path):
                file_path = os.path.abspath(file_path)
            if os.path.exists(file_path):
                detail["file_path"] = file_path
            else:
                fallback_original = self._original_file_path(
                    doc_id=doc_id,
                    filename=detail.get("filename", ""),
                    source_path=detail.get("filename", ""),
                )
                if os.path.exists(fallback_original):
                    detail["file_path"] = fallback_original

        chunks = self._get_stored_document_chunks(doc_id)
        if chunks:
            detail["chunks"] = chunks

        return detail

    @staticmethod
    def _infer_catalog_level(semantic_boundary: str, header: str, section_path: List[str]) -> int:
        boundary = str(semantic_boundary or "").lower()
        normalized_header = str(header or "").strip()

        if boundary == "chapter":
            return 1
        if boundary == "section":
            return 2
        if boundary == "article":
            return 3

        if re.match(r"^第[一二三四五六七八九十\d]+章", normalized_header):
            return 1
        if re.match(r"^第[一二三四五六七八九十\d]+节", normalized_header):
            return 2
        if re.match(r"^第[一二三四五六七八九十\d]+条", normalized_header):
            return 3

        return max(1, min(6, len(section_path) + 1))

    def _build_document_catalog_and_preview(
        self,
        chunks: List[Dict[str, Any]],
    ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[str]]:
        ordered_chunks = sorted(
            chunks,
            key=lambda c: (
                int(c.get("chunk_index", 0) or 0),
                int(c.get("global_index", 0) or 0),
            ),
        )

        enriched_chunks: List[Dict[str, Any]] = []
        catalog: List[Dict[str, Any]] = []
        preview_lines: List[str] = []
        seen_catalog_keys: Set[Tuple[str, ...]] = set()

        next_line_no = 1

        for chunk in ordered_chunks:
            chunk_copy = dict(chunk)
            raw_text = str(chunk_copy.get("text", "") or "")
            lines = raw_text.splitlines() or [""]
            line_start = next_line_no
            line_end = next_line_no + len(lines) - 1

            chunk_copy["line_start"] = line_start
            chunk_copy["line_end"] = line_end
            preview_lines.extend(lines)

            metadata = chunk_copy.get("metadata", {}) or {}
            header = str(metadata.get("header", "") or "").strip()
            semantic_boundary = str(metadata.get("semantic_boundary", "") or "")
            section_path_raw = metadata.get("section_path") or []
            section_path = [str(item).strip() for item in section_path_raw if str(item).strip()]

            if header:
                catalog_path = section_path.copy()
                if not catalog_path or catalog_path[-1] != header:
                    catalog_path.append(header)
                catalog_key = tuple(catalog_path) if catalog_path else (header,)

                if catalog_key not in seen_catalog_keys:
                    seen_catalog_keys.add(catalog_key)
                    anchor_line = line_start
                    for offset, line in enumerate(lines):
                        normalized_line = line.strip()
                        if normalized_line and normalized_line.startswith(header):
                            anchor_line = line_start + offset
                            break

                    catalog.append(
                        {
                            "id": f"catalog_{len(catalog) + 1}",
                            "title": header,
                            "level": self._infer_catalog_level(semantic_boundary, header, section_path),
                            "line_no": anchor_line,
                            "chunk_id": chunk_copy.get("chunk_id", ""),
                            "section_path": catalog_path,
                        }
                    )

            enriched_chunks.append(chunk_copy)
            next_line_no = line_end + 1

        return enriched_chunks, catalog, preview_lines

    @staticmethod
    def _normalize_for_line_match(text: str) -> str:
        return re.sub(r"\s+", "", str(text or ""))

    @staticmethod
    def _infer_catalog_node_type(semantic_boundary: str, header: str) -> str:
        boundary = str(semantic_boundary or "").strip().lower()
        normalized_header = str(header or "").strip()

        if boundary in {"chapter", "section", "article", "content"}:
            return boundary
        if normalized_header.startswith("第") and "章" in normalized_header:
            return "chapter"
        if normalized_header.startswith("第") and "节" in normalized_header:
            return "section"
        if normalized_header.startswith("第") and "条" in normalized_header:
            return "article"
        return "content"

    @staticmethod
    def _build_catalog_display_title(node_type: str, title: str) -> str:
        normalized_title = str(title or "").strip()
        if not normalized_title:
            return ""
        if node_type == "article":
            match = re.search(r"(第[一二三四五六七八九十百千万零〇两\d]+条)", normalized_title)
            if match:
                return match.group(1).strip()
        return normalized_title

    @classmethod
    def _build_catalog_preview_text(
        cls,
        text: str,
        section_path: List[str],
        title: str,
        display_title: str,
        node_type: str,
    ) -> str:
        if node_type != "article":
            return ""

        cleaned = PAGE_PATTERN.sub(" ", str(text or ""))
        cleaned = re.sub(r"\s+", " ", cleaned).strip()
        if not cleaned:
            return ""

        for prefix in [*section_path, title, display_title]:
            normalized_prefix = str(prefix or "").strip()
            if normalized_prefix and cleaned.startswith(normalized_prefix):
                cleaned = cleaned[len(normalized_prefix):].lstrip("：:，,。；;、-— \t")

        return cleaned[:120].strip()

    @classmethod
    def _extract_chunk_anchor_text(cls, chunk: Dict[str, Any]) -> str:
        metadata = chunk.get("metadata", {}) or {}
        header = str(metadata.get("header", "") or "").strip()
        raw_text = str(chunk.get("text", "") or "")
        if not raw_text:
            return header

        lines = [
            PAGE_PATTERN.sub("", str(line or "")).strip()
            for line in raw_text.splitlines()
        ]
        lines = [line for line in lines if line]
        if not lines:
            return header

        normalized_header = cls._normalize_for_line_match(header)
        header_idx = 0
        if normalized_header:
            for idx, line in enumerate(lines):
                normalized_line = cls._normalize_for_line_match(line)
                if normalized_line == normalized_header or normalized_line.startswith(normalized_header):
                    header_idx = idx
                    break

        anchor = lines[header_idx]
        if normalized_header and cls._normalize_for_line_match(anchor) == normalized_header:
            for next_line in lines[header_idx + 1: header_idx + 4]:
                normalized_next = cls._normalize_for_line_match(next_line)
                if not normalized_next:
                    continue
                if re.match(r"^第[一二三四五六七八九十百千万零〇两\d]+[章节条款]", next_line):
                    continue
                anchor = f"{anchor}{next_line}"
                break

        return anchor[:80].strip()

    def _find_chunk_line_no(
        self,
        full_text_lines: List[str],
        chunk: Dict[str, Any],
        start_idx: int = 0,
        skip_ranges: Optional[List[Tuple[int, int]]] = None,
    ) -> Optional[int]:
        if not full_text_lines:
            return None

        metadata = chunk.get("metadata", {}) or {}
        header = str(metadata.get("header", "") or "").strip()
        anchor_text = self._extract_chunk_anchor_text(chunk)

        normalized_anchor = self._normalize_for_line_match(anchor_text)
        normalized_header = self._normalize_for_line_match(header)
        min_anchor_len = max(len(normalized_header) + 4, 12)

        def match_at(index: int) -> bool:
            if skip_ranges and self._is_line_in_ranges(index, skip_ranges):
                return False
            normalized_line = self._normalize_for_line_match(full_text_lines[index])
            if not normalized_line:
                return False
            if normalized_anchor and len(normalized_anchor) >= min_anchor_len:
                if normalized_line.startswith(normalized_anchor) or normalized_anchor.startswith(normalized_line):
                    return True
            if normalized_header and normalized_line.startswith(normalized_header):
                return True
            return False

        for idx in range(max(0, start_idx), len(full_text_lines)):
            if match_at(idx):
                return idx + 1

        for idx in range(0, max(0, start_idx)):
            if match_at(idx):
                return idx + 1

        return None

    @staticmethod
    def _detect_special_root_headings(full_text_lines: List[str]) -> List[Dict[str, Any]]:
        roots: List[Dict[str, Any]] = []
        for idx, raw_line in enumerate(full_text_lines):
            line = str(raw_line or "").strip()
            if not line:
                continue
            if not ACCOUNTING_STANDARD_ROOT_PATTERN.match(line):
                continue
            roots.append(
                {
                    "title": line,
                    "line_no": idx + 1,
                    "level": 1,
                    "section_path": [line],
                    "node_type": "root",
                    "display_title": line,
                    "preview_text": "",
                    "chunk_id": "",
                }
            )
        return roots

    @staticmethod
    def _find_active_root_heading(root_headings: List[Dict[str, Any]], line_no: int) -> Optional[Dict[str, Any]]:
        active: Optional[Dict[str, Any]] = None
        for item in root_headings:
            if int(item.get("line_no", 0) or 0) <= line_no:
                active = item
                continue
            break
        return active

    def _split_full_text_lines_with_page_map(self, full_text: str) -> Tuple[List[str], List[Optional[int]]]:
        lines: List[str] = []
        line_pages: List[Optional[int]] = []
        current_page: Optional[int] = None

        for raw_line in str(full_text or "").splitlines():
            matches = PAGE_PATTERN.findall(raw_line)
            if matches:
                try:
                    current_page = int(matches[-1])
                except ValueError:
                    current_page = current_page

            cleaned_line = PAGE_PATTERN.sub("", raw_line).strip()
            if not cleaned_line:
                continue

            lines.append(cleaned_line)
            line_pages.append(current_page)

        return lines, line_pages

    @staticmethod
    def _is_line_in_ranges(index: int, ranges: List[Tuple[int, int]]) -> bool:
        for start, end in ranges:
            if start <= index <= end:
                return True
        return False

    @staticmethod
    def _looks_like_toc_heading_line(line: str) -> bool:
        normalized = str(line or "").strip()
        if not normalized:
            return False
        if normalized in {"序言", "附录"}:
            return True
        if re.match(r"^第[一二三四五六七八九十百千万\d]+[章节]\s*", normalized):
            return True
        if re.match(r"^第[一二三四五六七八九十百千万\d]+节", normalized):
            return True
        if re.search(r"[·.。]{2,}\s*\d+\s*$", normalized):
            return True
        return False

    def _detect_toc_line_ranges(self, full_text_lines: List[str]) -> List[Tuple[int, int]]:
        ranges: List[Tuple[int, int]] = []
        idx = 0
        total = len(full_text_lines)

        while idx < total:
            normalized = str(full_text_lines[idx] or "").strip()
            if normalized not in {"目录", "目 录", "目录：", "目 录："}:
                idx += 1
                continue

            start = idx
            cursor = idx + 1
            heading_count = 0

            while cursor < total and (cursor - start) <= 140:
                line = str(full_text_lines[cursor] or "").strip()
                if not line:
                    cursor += 1
                    continue
                if self._looks_like_toc_heading_line(line):
                    heading_count += 1
                    cursor += 1
                    continue
                break

            if heading_count >= 3:
                ranges.append((start, max(start, cursor - 1)))
                idx = cursor
            else:
                idx += 1

        return ranges

    def _find_header_line_no(
        self,
        full_text_lines: List[str],
        header: str,
        start_idx: int = 0,
        skip_ranges: Optional[List[Tuple[int, int]]] = None,
    ) -> Optional[int]:
        if not full_text_lines:
            return None

        normalized_header = self._normalize_for_line_match(header)
        if not normalized_header:
            return None

        for idx in range(max(0, start_idx), len(full_text_lines)):
            if skip_ranges and self._is_line_in_ranges(idx, skip_ranges):
                continue
            normalized_line = self._normalize_for_line_match(full_text_lines[idx])
            if normalized_line.startswith(normalized_header):
                return idx + 1

        for idx, line in enumerate(full_text_lines):
            if skip_ranges and self._is_line_in_ranges(idx, skip_ranges):
                continue
            normalized_line = self._normalize_for_line_match(line)
            if normalized_line.startswith(normalized_header):
                return idx + 1

        return None

    def _find_header_line_no_before(
        self,
        full_text_lines: List[str],
        header: str,
        end_idx: int,
        skip_ranges: Optional[List[Tuple[int, int]]] = None,
        max_window: int = 160,
    ) -> Optional[int]:
        if not full_text_lines:
            return None

        normalized_header = self._normalize_for_line_match(header)
        if not normalized_header:
            return None

        end_idx = min(max(0, end_idx), len(full_text_lines) - 1)
        start_idx = max(0, end_idx - max(0, max_window) + 1)

        for idx in range(end_idx, start_idx - 1, -1):
            if skip_ranges and self._is_line_in_ranges(idx, skip_ranges):
                continue
            normalized_line = self._normalize_for_line_match(full_text_lines[idx])
            if normalized_line.startswith(normalized_header):
                return idx + 1

        for idx in range(end_idx, -1, -1):
            if skip_ranges and self._is_line_in_ranges(idx, skip_ranges):
                continue
            normalized_line = self._normalize_for_line_match(full_text_lines[idx])
            if normalized_line.startswith(normalized_header):
                return idx + 1

        return None

    def _build_catalog_from_full_text(
        self,
        chunks: List[Dict[str, Any]],
        full_text_lines: List[str],
    ) -> List[Dict[str, Any]]:
        ordered_chunks = sorted(
            chunks,
            key=lambda c: (
                int(c.get("chunk_index", 0) or 0),
                int(c.get("global_index", 0) or 0),
            ),
        )

        catalog_by_key: Dict[Tuple[str, ...], Dict[str, Any]] = {}
        search_start_idx = 0
        toc_ranges = self._detect_toc_line_ranges(full_text_lines)
        root_headings = self._detect_special_root_headings(full_text_lines)

        for root in root_headings:
            catalog_by_key[tuple(root.get("section_path", []))] = dict(root)

        for chunk in ordered_chunks:
            metadata = chunk.get("metadata", {}) or {}
            header = str(metadata.get("header", "") or "").strip()
            semantic_boundary = str(metadata.get("semantic_boundary", "") or "")
            section_path_raw = metadata.get("section_path") or []
            section_path = [str(item).strip() for item in section_path_raw if str(item).strip()]

            if not header and not section_path:
                continue

            node_titles = section_path.copy()
            if header and (not node_titles or node_titles[-1] != header):
                node_titles.append(header)

            if not node_titles:
                continue

            line_no = self._find_chunk_line_no(
                full_text_lines,
                chunk,
                start_idx=search_start_idx,
                skip_ranges=toc_ranges,
            )
            if line_no is not None:
                search_start_idx = max(search_start_idx, line_no - 1)
            else:
                fallback_title = header or (node_titles[-1] if node_titles else "")
                line_no = self._find_header_line_no(
                    full_text_lines,
                    fallback_title,
                    start_idx=search_start_idx,
                    skip_ranges=toc_ranges,
                )
                if line_no is not None:
                    search_start_idx = max(search_start_idx, line_no - 1)
                else:
                    line_no = 1

            active_root = self._find_active_root_heading(root_headings, line_no)
            root_title = str((active_root or {}).get("title", "") or "").strip()
            root_prefix = [root_title] if root_title else []

            node_line_nos: List[int] = [line_no] * len(node_titles)
            if len(node_titles) > 1:
                cursor_end = max(0, line_no - 2)
                for reverse_idx in range(len(node_titles) - 2, -1, -1):
                    candidate_line = self._find_header_line_no_before(
                        full_text_lines,
                        node_titles[reverse_idx],
                        end_idx=cursor_end,
                        skip_ranges=toc_ranges,
                    )
                    if candidate_line is None:
                        candidate_line = node_line_nos[reverse_idx + 1]
                    node_line_nos[reverse_idx] = candidate_line
                    cursor_end = max(0, candidate_line - 2)

            for idx, node_title in enumerate(node_titles):
                catalog_path = root_prefix + node_titles[: idx + 1]
                catalog_key = tuple(catalog_path)
                node_line_no = node_line_nos[idx] if idx < len(node_line_nos) else line_no

                if idx == len(node_titles) - 1 and header:
                    level = self._infer_catalog_level(semantic_boundary, header, section_path)
                    node_type = self._infer_catalog_node_type(semantic_boundary, header)
                else:
                    level = max(1, min(6, idx + 1))
                    node_type = self._infer_catalog_node_type("", node_title)

                if root_title:
                    level += 1

                display_title = self._build_catalog_display_title(node_type, node_title)
                preview_text = self._build_catalog_preview_text(
                    str(chunk.get("text", "") or ""),
                    catalog_path[:-1],
                    node_title,
                    display_title,
                    node_type,
                )

                candidate = {
                    "title": node_title,
                    "display_title": display_title,
                    "preview_text": preview_text,
                    "node_type": node_type,
                    "level": level,
                    "line_no": node_line_no,
                    "chunk_id": chunk.get("chunk_id", ""),
                    "section_path": catalog_path,
                }

                existing = catalog_by_key.get(catalog_key)
                # 避免PDF“目录页”先命中造成正文章节缺失：同路径取更靠后的命中
                if existing is None or int(candidate["line_no"]) >= int(existing["line_no"]):
                    catalog_by_key[catalog_key] = candidate

        catalog_items = list(catalog_by_key.values())
        for item in catalog_items:
            node_type = str(item.get("node_type", "") or "")
            if node_type not in {"chapter", "section", "root"}:
                continue
            section_path = tuple(str(part).strip() for part in (item.get("section_path") or []) if str(part).strip())
            if not section_path:
                continue

            child_line_nos = [
                int(candidate.get("line_no", 0) or 0)
                for candidate in catalog_items
                if tuple(str(part).strip() for part in (candidate.get("section_path") or []) if str(part).strip())[:len(section_path)] == section_path
                and len(tuple(str(part).strip() for part in (candidate.get("section_path") or []) if str(part).strip())) > len(section_path)
                and int(candidate.get("line_no", 0) or 0) > 0
            ]
            if child_line_nos:
                item["line_no"] = min(child_line_nos)

        catalog = sorted(
            catalog_items,
            key=lambda item: (int(item.get("line_no", 0) or 0), int(item.get("level", 0) or 0)),
        )

        duplicate_article_titles = defaultdict(int)
        for item in catalog:
            if str(item.get("node_type", "")) != "article":
                continue
            display_title = str(item.get("display_title", "") or item.get("title", "")).strip()
            if display_title:
                duplicate_article_titles[display_title] += 1

        for item in catalog:
            if str(item.get("node_type", "")) != "article":
                continue
            display_title = str(item.get("display_title", "") or item.get("title", "")).strip()
            if duplicate_article_titles.get(display_title, 0) <= 1:
                continue
            section_path = [str(part).strip() for part in (item.get("section_path") or []) if str(part).strip()]
            context_parts = [part for part in section_path[:-1] if "第" not in part or "条" not in part]
            context = ""
            if context_parts:
                context = context_parts[0] if len(context_parts) == 1 else " / ".join(context_parts[-2:])
            page_no = item.get("page_no")
            if not context and isinstance(page_no, int) and page_no > 0:
                context = f"P{page_no}"
            if context:
                item["display_title"] = f"{context} · {display_title}"

        for i, item in enumerate(catalog):
            item["id"] = f"catalog_{i + 1}"

        return catalog

    def _resolve_document_full_text(self, record: DocumentRecord) -> Tuple[List[str], List[Optional[int]], str]:
        doc_id = record.doc_id

        stored_text = self._load_full_text(doc_id)
        if stored_text is not None:
            lines, line_pages = self._split_full_text_lines_with_page_map(stored_text)
            return lines, line_pages, "stored_full_text"

        file_path = str(record.file_path or "").strip()
        if file_path and not os.path.isabs(file_path):
            file_path = os.path.abspath(file_path)
        if file_path and os.path.exists(file_path):
            try:
                from src.ingestion.parsers.document_processor import DocumentProcessor

                loaded_text = DocumentProcessor.load_document(file_path, doc_type=record.doc_type)
                self._save_full_text(doc_id, loaded_text)
                lines, line_pages = self._split_full_text_lines_with_page_map(loaded_text)
                return lines, line_pages, "reloaded_file"
            except Exception as e:
                logger.warning("从文件回读原文失败: doc_id=%s file_path=%s err=%s", doc_id, file_path, e)

        return [], [], "missing_full_text"

    def get_document_chunks(self, doc_id: str, include_text: bool = True, include_chunks: bool = True) -> Dict:
        self._refresh_metadata_store()
        record = self.metadata_store.get_document(doc_id)
        if not record:
            return {"error": "文档不存在"}

        raw_chunks = self._get_stored_document_chunks(doc_id)
        if not raw_chunks:
            return {"error": "文档没有可用分块"}
        chunks, _, fallback_preview_lines = self._build_document_catalog_and_preview(raw_chunks)
        full_text_lines, full_text_line_pages, full_text_source = self._resolve_document_full_text(record)
        if not full_text_lines:
            full_text_lines = fallback_preview_lines
            full_text_line_pages = [None] * len(full_text_lines)
            full_text_source = "chunk_fallback"

        catalog = self._build_catalog_from_full_text(chunks, full_text_lines)
        chunk_page_hint: Dict[str, Optional[int]] = {}
        for c in chunks:
            page_nos = (c.get("metadata", {}) or {}).get("page_nos", []) or []
            chunk_page_hint[str(c.get("chunk_id", ""))] = int(page_nos[0]) if page_nos else None
        for item in catalog:
            line_no = int(item.get("line_no", 0) or 0)
            page_no: Optional[int] = None
            if 1 <= line_no <= len(full_text_line_pages):
                page_no = full_text_line_pages[line_no - 1]
            if page_no is None:
                page_no = chunk_page_hint.get(str(item.get("chunk_id", "")))
            item["page_no"] = page_no

        total_chars = sum(c["char_count"] for c in chunks)
        avg_chunk_size = total_chars // len(chunks) if chunks else 0
        total_lines = len(full_text_lines)

        if not include_text:
            full_text_lines = []
        if include_chunks:
            if not include_text:
                chunks = [{k: v for k, v in c.items() if k != "text"} for c in chunks]
        else:
            chunks = []

        return {
            "doc_id": doc_id,
            "filename": record.filename,
            "doc_type": record.doc_type,
            "upload_time": record.upload_time,
            "chunk_count": len(chunks),
            "total_chars": total_chars,
            "avg_chunk_size": avg_chunk_size,
            "total_lines": total_lines,
            "full_text_source": full_text_source,
            "catalog": catalog,
            "full_text_lines": full_text_lines,
            "chunks": chunks,
        }

    def delete_document(self, doc_id: str) -> Dict:
        self._refresh_metadata_store()
        record = self.metadata_store.get_document(doc_id)
        if not record:
            return {"success": False, "error": "文档不存在"}
        if not self.metadata_store.delete_document(doc_id, soft_delete=False):
            return {"success": False, "error": "文档不存在"}

        removed_chunks = 0
        removed_full_text = self._delete_full_text(doc_id)
        removed_preview_chunks = self._delete_preview_chunks(doc_id)
        removed_original_file = False
        original_path = str(record.file_path or "").strip() if record else ""
        if original_path and not os.path.isabs(original_path):
            original_path = os.path.abspath(original_path)
        if original_path and os.path.exists(original_path):
            try:
                os.remove(original_path)
                removed_original_file = True
            except Exception as e:
                logger.warning("删除原始文件失败: doc_id=%s path=%s err=%s", doc_id, original_path, e)
        if self.vector_store:
            removed_chunks = self.vector_store.remove_document_chunks(doc_id)

        if self.vector_store:
            self.save_vector_store(self.vector_store_path)
            self.rebuild_graph_index(save=True)

        return {
            "success": True,
            "doc_id": doc_id,
            "removed_chunks": removed_chunks,
            "removed_full_text": removed_full_text,
            "removed_preview_chunks": removed_preview_chunks,
            "removed_original_file": removed_original_file,
        }

    def get_document_stats(self) -> Dict:
        self._refresh_metadata_store()
        return self.metadata_store.get_stats()

    def clear_all_documents(self) -> Dict:
        doc_stats = self.metadata_store.clear_all(delete_storage_file=True)

        if self.vector_store:
            self.clear_vector_store()
            if self.retriever:
                self.retriever = VectorRetriever(self.vector_store, self.embedding_provider)

        removed_vector_files = 0
        for suffix in (".index", ".docs", ".graph.json"):
            path = f"{self.vector_store_path}{suffix}"
            if os.path.exists(path):
                os.remove(path)
                removed_vector_files += 1

        removed_full_text_files = 0
        full_text_dir = self._full_text_store_dir()
        if os.path.isdir(full_text_dir):
            removed_full_text_files = sum(1 for name in os.listdir(full_text_dir) if name.endswith(".txt"))
            shutil.rmtree(full_text_dir, ignore_errors=True)

        removed_preview_files = 0
        preview_dir = self._preview_store_dir()
        if os.path.isdir(preview_dir):
            removed_preview_files = sum(1 for name in os.listdir(preview_dir) if name.endswith(".json"))
            shutil.rmtree(preview_dir, ignore_errors=True)

        removed_original_files = 0
        original_dir = self._original_store_dir()
        if os.path.isdir(original_dir):
            removed_original_files = sum(1 for name in os.listdir(original_dir) if os.path.isfile(os.path.join(original_dir, name)))
            shutil.rmtree(original_dir, ignore_errors=True)

        return {
            "success": True,
            "removed_documents": doc_stats.get("removed_total", 0),
            "removed_active_documents": doc_stats.get("removed_active", 0),
            "removed_deleted_documents": doc_stats.get("removed_deleted", 0),
            "removed_vector_files": removed_vector_files,
            "removed_full_text_files": removed_full_text_files,
            "removed_preview_files": removed_preview_files,
            "removed_original_files": removed_original_files,
        }


def process_user_uploaded_documents(file_paths: List[str], rag_processor: RAGProcessor):
    from src.ingestion.parsers.document_processor import process_uploaded_documents

    processed_documents = process_uploaded_documents(file_paths)
    if not processed_documents:
        return 0
    return rag_processor.process_documents(processed_documents)
